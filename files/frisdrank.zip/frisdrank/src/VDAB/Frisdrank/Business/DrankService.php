<?php

namespace VDAB\Frisdrank\Business;
use VDAB\Frisdrank\Data\DrankDAO;

class DrankService {

  public function geefAlleDranken() {
    $dranken = new DrankDAO();
    return $dranken->geefAlleDranken();
  }

  public function geefPrijsVanDrank($id) {
    $drankDAO = new DrankDAO();
    return $drankDAO->geefPrijsVanDrankjeMetId($id);
  }

  public function verwerkSelectie($id) {
    $drankDAO = new DrankDAO();
    $muntService = new MuntService();

    $prijs = $this->geefPrijsVanDrank($id);
    if ($muntService->kanTeruggeven($prijs) && $prijs <= $muntService->geefTotaalIngeworpen()) {
      $drankDAO->verminderAantalMetEen($id);
      $prijsDrank = $drankDAO->geefPrijsVanDrankjeMetId($id);
      $muntService->berekenTeruggave($prijsDrank);
      return true;
    } else {
      return false;
    }
  }

  public function voegAantalToe($aantal) {
    switch ($aantal) {
      case 1:
        $this->voegEenToe($_GET["id"]);
        break;
      case 5:
        $this->voegVijfToe($_GET["id"]);
        break;
      default :
        $this->voegMaxToe($_GET["id"]);
        break;
    }
  }

  public function voegEenToe($id) {
    $drankDAO = new DrankDAO();
    $drankDAO->voegEenToe($id);
  }

  public function voegVijfToe($id) {
    $drankDAO = new DrankDAO();
    $drankDAO->voegVijfToe($id);
  }

  public function voegMaxToe($id) {
    $drankDAO = new DrankDAO();
    $drankDAO->voegMaxToe($id);
  }

}
