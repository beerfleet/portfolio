<?php

namespace VDAB\Frisdrank\Business;

use VDAB\Frisdrank\Data\GebruikerDAO;
use VDAB\Frisdrank\Entities\Gebruiker;
use VDAB\Frisdrank\Lib\BCrypt;


class GebruikerService {

  public function verifieerGebruiker($naam, $paswoord) {
    $gebruikerDAO = new GebruikerDAO();
    $gebruiker = $gebruikerDAO->getUserByNaam($naam);
    $crypto = new BCrypt();    
    return $crypto->password_verify($paswoord, $gebruiker->getPaswoord());
  }

}
