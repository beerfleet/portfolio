<?php

namespace VDAB\Frisdrank\Business;

use VDAB\Frisdrank\Data\MuntDAO;
use VDAB\Frisdrank\Entities\Teruggave;

class MuntService {

  private $munten;

  public function __construct() {
    $this->munten = $this->geefMuntenDesc();
  }

  public function geefMuntenDesc() {
    $muntenDAO = new MuntDAO();
    return $muntenDAO->getMuntenDesc();
  }

  public function geefMunten() {
    $munten = new MuntDAO();
    return $munten->getMunten();
  }

  public function werpMuntIn($id) {
    $geldlade = new MuntDAO();
    $munt = $geldlade->getMuntMetId($id);
    $ingeworpen = $munt->getIngeworpen();
    $geldlade->voegIngeworpenToe($id, $ingeworpen);
  }

  public function geefTotaalIngeworpen() {
    $totaal = 0;
    foreach ($this->munten as $munt) {
      $totaal += $munt->getIngeworpen() * $munt->getWaarde();
    }
    return $totaal;
  }

  public function geefSaldoTerug() {
    $geldlade = new MuntDAO();
    $geldlade->clearIngeworpen();
  }

  public function berekenTeruggave($prijs) {
    $restBedrag = $this->geefTotaalIngeworpen() - $prijs;
    $this->voegMuntenAanLadeToe();
    $this->munten = $this->geefMuntenDesc();
    $teruggave = new Teruggave($this->munten, $restBedrag);
    $teruggave->berekenWisselgeld($this->munten);
    $this->updateTeruggave($this->munten);
  }

  public function kanTeruggeven($prijs) {
    $restBedrag = $this->geefTotaalIngeworpen() - $prijs;
    $teruggave = new Teruggave($this->munten, $restBedrag);
    return $teruggave->kanTeruggeven();
  }

  public function updateTeruggave($munten) {
    $muntDAO = new MuntDAO();
    foreach ($munten as $munt) {
      $muntDAO->updateTeruggave($munt);
    }
  }

  public function voegMuntenAanLadeToe() {
    $muntDAO = new MuntDAO();
    foreach ($this->munten as $munt) {
      $muntDAO->verplaatsMuntNaarGeldlade($munt);
    }
  }

  public function totaalGeldInAutomaat() {
    $muntDAO = new MuntDAO();
    $munten = $muntDAO->getMunten();
    $totaal = 0;
    foreach ($munten as $munt) {
      $totaal += $munt->getAantal() * $munt->getWaarde();
    }
    return $totaal;
  }

  public function leegLade() {
    $muntDAO = new MuntDAO();
    $muntDAO->clearAantal();
  }

}
