<?php

namespace VDAB\Frisdrank\Entities;

use PDO;

class DBHelper {

  private static $CONN_STR = "mysql:host=127.0.0.1;dbname=frisdrankdb";
  private static $USER = "gebruiker";
  private static $PASSW = "Appel.Sap";

  static public function connect() {
    return new PDO(self::$CONN_STR, self::$USER, self::$PASSW);
  }
}
