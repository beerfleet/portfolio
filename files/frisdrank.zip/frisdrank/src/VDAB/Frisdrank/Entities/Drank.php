<?php

namespace VDAB\Frisdrank\Entities;

class Drank {

  private $id;
  private $naam;
  private $bestandsnaam;
  private $prijs;
  private $aantal;

  function __construct($id, $naam, $bestandsnaam, $prijs, $aantal) {
    $this->id = $id;
    $this->naam = $naam;
    $this->bestandsnaam = $bestandsnaam;
    $this->prijs = $prijs;
    $this->aantal = $aantal;
  }

  public function uitverkocht() {
    return $this->aantal == 0;
  }

  public function getId() {
    return $this->id;
  }

  public function getNaam() {
    return $this->naam;
  }

  public function getBestandsnaam() {
    return $this->bestandsnaam;
  }

  public function getPrijs() {
    return $this->prijs;
  }

  public function getAantal() {
    return $this->aantal;
  }

  public function setId($id) {
    $this->id = $id;
  }

  public function setNaam($naam) {
    $this->naam = $naam;
  }

  public function setBestandsnaam($bestandsnaam) {
    $this->bestandsnaam = $bestandsnaam;
  }

  public function setPrijs($prijs) {
    $this->prijs = $prijs;
  }

  public function setAantal($aantal) {
    $this->aantal = $aantal;
  }

}
