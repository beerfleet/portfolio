<?php

namespace VDAB\Frisdrank\Entities;

class Teruggave {

  private $munten;
  private $bedrag;

  function __construct($munten, $bedrag) {
    $this->munten = $munten;
    $this->bedrag = $bedrag;
  }

  private function hoeveelKeerGaatXinY($x, $y) {
    return floor($y / $x);
  }

  public function kanTeruggeven() {
    $rest = $this->bedrag;
    foreach ($this->munten as $munt) {
      $geheleDeling = $this->hoeveelKeerGaatXinY($munt->getWaarde(), $rest);
      if ($geheleDeling > $munt->getAantal()) {
        $geheleDeling = $munt->getAantal();
      } 
      $rest -= $munt->getWaarde() * $geheleDeling;
    }    
    return $rest == 0;
  }

  public function berekenWisselgeld($munten) {
    $rest = $this->bedrag;
    foreach ($munten as $munt) {
      $geheleDeling = $this->hoeveelKeerGaatXinY($munt->getWaarde(), $rest);
      if ($geheleDeling > $munt->getAantal()) {
        $geheleDeling = $munt->getAantal();
        $munt->setIngeworpen($munt->getAantal());
        $munt->setAantal(0);
      } else {
        $munt->setIngeworpen($geheleDeling);
        $munt->setAantal($munt->getAantal() - $geheleDeling);
      }
      $rest -= $munt->getWaarde() * $geheleDeling;      
    }    
  }

}
