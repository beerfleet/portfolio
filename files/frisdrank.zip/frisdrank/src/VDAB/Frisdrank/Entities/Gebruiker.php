<?php

namespace VDAB\Frisdrank\Entities;


/**
 * Description of Gebruiker
 *
 * @author Kukulkan
 */
class Gebruiker {

  private $id;
  private $naam;
  private $paswoord;

  function __construct($naam, $paswoord) {    
    $this->naam = $naam;
    $this->paswoord = $paswoord;
  }

  public function getId() {
    return $this->id;
  }

  public function getNaam() {
    return $this->naam;
  }

  public function getPaswoord() {
    return $this->paswoord;
  }

  public function setId($id) {
    $this->id = $id;
  }

  public function setNaam($naam) {
    $this->naam = $naam;
  }

  public function setPaswoord($paswoord) {
    $this->paswoord = $paswoord;
  }

}
