<?php


namespace VDAB\Frisdrank\Entities;


class Munt {

  private $id;
  private $omschrijving;
  private $waarde;
  private $aantal;
  private $ingeworpen;

  function __construct($id, $omschrijving, $waarde, $aantal, $ingeworpen) {
    $this->id = $id;
    $this->omschrijving = $omschrijving;
    $this->waarde = $waarde;
    $this->aantal = $aantal;
    $this->ingeworpen = $ingeworpen;
  }
  
  public function verplaatsNaarGeldlade() {
    $this->setAantal($this->aantal + $this->ingeworpen);
    $this->ingeworpen = 0;
  }

  public function getId() {
    return $this->id;
  }

  public function getOmschrijving() {
    return $this->omschrijving;
  }

  public function getWaarde() {
    return $this->waarde;
  }

  public function setId($id) {
    $this->id = $id;
  }

  public function setOmschrijving($omschrijving) {
    $this->omschrijving = $omschrijving;
  }

  public function setWaarde($waarde) {
    $this->waarde = $waarde;
  }

  public function getAantal() {
    return $this->aantal;
  }

  public function setAantal($aantal) {
    $this->aantal = $aantal;
  }

  public function getIngeworpen() {
    return $this->ingeworpen;
  }

  public function setIngeworpen($ingeworpen) {
    $this->ingeworpen = $ingeworpen;
  }

}
