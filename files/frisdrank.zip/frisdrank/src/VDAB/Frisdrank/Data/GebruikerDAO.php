<?php

namespace VDAB\Frisdrank\Data;

use VDAB\Frisdrank\Entities\Gebruiker;
use VDAB\Frisdrank\Entities\DBHelper;
use PDO;

class GebruikerDAO {

  public function addUser(Gebruiker $gebruiker) {
    $sql = "INSERT INTO "
            . "gebruikers (naam, paswoord) "
            . "values ('" . $gebruiker->getNaam() . "', '" . $gebruiker->getPaswoord() . "')";
    $dbh = DBHelper::connect();
    $dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $dbh->exec($sql);
    $dbh = null;
  }

  public function getUserByNaam($naam) {
    $sql = "SELECT naam, paswoord FROM gebruikers WHERE naam = '" . $naam . "'";
    $dbh = DBHelper::connect();
    $dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $resultSet = $dbh->query($sql);
    $gebruiker = $resultSet->fetch();
    return new Gebruiker($gebruiker["naam"], $gebruiker["paswoord"]);
  }

}
