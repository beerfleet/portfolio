<?php

namespace VDAB\Frisdrank\Data;

use VDAB\Frisdrank\Entities\Munt;
use VDAB\Frisdrank\Entities\DBHelper;
use PDO;

class MuntDAO {

  public function getMunten() {
    $lijst = array();
    $sql = "SELECT id, omschrijving, waarde, aantal, ingeworpen "
            . "FROM geldlade ORDER BY waarde";
    $dbh = DBHelper::connect();
    $dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $resultSet = $dbh->query($sql);
    foreach ($resultSet as $munt) {
      $lijst[] = new Munt($munt["id"], $munt["omschrijving"], $munt["waarde"], $munt["aantal"], $munt["ingeworpen"]);
    }
    $dbh = null;
    return $lijst;
  }

  public function getMuntenDesc() {
    $lijst = array();
    $sql = "SELECT id, omschrijving, waarde, aantal, ingeworpen "
            . "FROM geldlade ORDER BY waarde DESC";
    $dbh = DBHelper::connect();
    $dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $resultSet = $dbh->query($sql);

    foreach ($resultSet as $munt) {
      $lijst[] = new Munt($munt["id"], $munt["omschrijving"], $munt["waarde"], $munt["aantal"], $munt["ingeworpen"]);
    }
    $dbh = null;
    return $lijst;
  }

  public function getMuntMetId($id) {
    $sql = "SELECT id, omschrijving, waarde, aantal, ingeworpen "
            . "FROM geldlade "
            . "WHERE id=" . $id;
    $dbh = DBHelper::connect();
    $dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $resultSet = $dbh->query($sql);
    $munt = $resultSet->fetch();
    $dbh = null;
    return new Munt($munt["id"], $munt["omschrijving"], $munt["waarde"], $munt["aantal"], $munt["ingeworpen"]);
  }

  public function voegIngeworpenToe($id, $ingeworpen) {
    $sql = "UPDATE geldlade "
            . "SET ingeworpen = " . ++$ingeworpen
            . " WHERE id = " . $id;

    $dbh = DBHelper::connect();

    $dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $dbh->exec($sql);
    $dbh = null;
  }

  public function verplaatsMuntNaarGeldlade($munt) {
    $munt->verplaatsNaarGeldlade();
    $sql = "UPDATE geldlade "
            . "SET aantal = " . $munt->getAantal()
            . " WHERE id = " . $munt->getId();

    $dbh = DBHelper::connect();
    $dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $dbh->exec($sql);
    $dbh = null;
  }

  public function updateTeruggave($munt) {
    $sql = "UPDATE geldlade SET ingeworpen = " . $munt->getIngeworpen()
            . ", aantal = " . $munt->getAantal()
            . " WHERE id = " . $munt->getId();

    $dbh = DBHelper::connect();
    $dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $dbh->exec($sql);
    $dbh = null;
  }

  public function clearIngeworpen() {
    $sql = "UPDATE geldlade "
            . "SET ingeworpen = 0";
    $dbh = DBHelper::connect();
    $dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $dbh->exec($sql);
    $dbh = null;
  }

  public function clearAantal() {
    $sql = "UPDATE geldlade "
            . "SET aantal = 0";
    $dbh = DBHelper::connect();
    $dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $dbh->exec($sql);
    $dbh = null;
  }

}
