<?php

namespace VDAB\Frisdrank\Data;

use VDAB\Frisdrank\Entities\DBHelper;
use VDAB\Frisdrank\Entities\Drank;
use PDO;

class DrankDAO {

  public function geefAlleDranken() {
    $lijst = array();
    $sql = "SELECT id, naam, bestandsnaam, aantal, prijs "
            . "FROM dranken ORDER BY id ASC";
    $dbh = DBHelper::connect();
    $dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $resultSet = $dbh->query($sql);
    if ($resultSet->rowCount() == 0)
      throw new NoResultException("Er bevinden zich geen dranken in de database");
    foreach ($resultSet as $drank) {
      $lijst[] = new Drank($drank["id"], $drank["naam"], $drank["bestandsnaam"], $drank["prijs"], $drank["aantal"]);
    }
    $dbh = null;
    return $lijst;
  }

  public function geefPrijsVanDrankjeMetId($id) {
    $drankje = $this->geefDrankjeMetId($id);
    return $drankje->getPrijs();
  }

  public function geefDrankjeMetId($id) {
    // zoek de drank op, en het aantal over
    $sql = "SELECT id, naam, aantal, prijs "
            . "FROM dranken "
            . "WHERE id = " . $id;

    $dbh = DBHelper::connect();
    $dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $resultSet = $dbh->query($sql);
    $dbh = null;
    $drank = $resultSet->fetch();
    return new Drank($drank["id"], $drank["naam"], $drank["bestandsnaam"], $drank["prijs"], $drank["aantal"]);
  }

  public function updateAantalMetDrankId($id, $aantal) {
    $sql = "UPDATE dranken SET "
            . "aantal = " . $aantal
            . " WHERE id = " . $id;
    $dbh = DBHelper::connect();
    $dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $dbh->exec($sql);
    $dbh = null;
  }

  public function verminderAantalMetEen($id) {
    $drank = $this->geefDrankjeMetId($id);
    $this->updateAantalMetDrankId($id, $drank->getAantal() - 1);
    $dbh = null;
  }
  
  public function voegEenToe($id) {
    $drank = $this->geefDrankjeMetId($id);
    $this->updateAantalMetDrankId($id, $drank->getAantal() + 1);
    $dbh = null;
  }
  
  public function voegMaxToe($id) {    
    $this->updateAantalMetDrankId($id, 20);
    $dbh = null;
  }

  public function voegVijfToe($id) {
    $drank = $this->geefDrankjeMetId($id);
    $aantal = $drank->getAantal();
    $aantal = $aantal > 15 ? 20 : $aantal + 5;
    $this->updateAantalMetDrankId($id, $aantal);
    $dbh = null;
  }

}
