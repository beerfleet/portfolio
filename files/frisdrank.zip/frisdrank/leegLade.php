<?php

use VDAB\Frisdrank\Business\MuntService;
use Doctrine\Common\ClassLoader;

require_once './Doctrine/Common/ClassLoader.php';

$classloader = new ClassLoader("VDAB", "src");
$classloader->register();

if (isset($_GET["action"]) && $_GET["action"] == "leeg") {
  $muntSrvc = new MuntService();
  $muntSrvc->leegLade();
  header("Location: adminPage.php");
  exit(0);
}