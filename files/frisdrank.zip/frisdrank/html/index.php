<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <title>Frisdrankautomaat</title>
    <link href="css/drankautomaat.css" rel="stylesheet">
    <!--[if lt IE 9]>
<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
<![endif]-->
  </head>  
  <body>
    <header class="schaduw">
      
      <section id="logon" >        
        <form action="./adminPage.php" method="post">
          <label for="username">Username</label>
          <input type="text" id="username" name="username">
          <label for="password">Password</label>
          <input type="password" id="password" name="password">
          <input type="submit" value="Login">
        </form>
        <?php
        if (isset($ongeldigeLogin) && $ongeldigeLogin) {
          ?><p class="fout">Ongeldige login</p><?php
        }
        ?>
      </section>
      
      <!-- ERROR WEERGAVE MUNTSTUKKEN --> 
      <section id="message">
        <?php
        if (isset($_GET["action"]) && $_GET["action"] == "kannietteruggeven") {
          ?><div class="msg">Kan niet teruggeven, gelieve een ander dranje te kiezen</div><?php
        } else if (isset($_GET["action"]) && $_GET["action"] == "drankgekocht") {
          ?><div class="msg">Uw drankje ligt klaar in de lade</div><?php
        }
        ?>
      </section>
      
    </header>
    <!-- WRAPPER  -->
    <div id="wrapper" class="schaduw">

      <section id="drankdisplay"> <!-- CONTAINER VOOR DE DRANKEN -->
        <?php
        foreach ($dranken as $drank) {
          $uitverkocht = $drank->uitverkocht();
          $genoegSaldo = $muntSrvc->geefTotaalIngeworpen() >= $drank->getPrijs();
          ?> 

          <!-- CONTAINER DRANK -->
          <div class="drankcell vlotlinks"> 

            <!-- CONTAINER DRANKINTERFACE -->
            <div> 
              <?php
              if ($uitverkocht || !$genoegSaldo) {
                ?>        
                <img src="img/<?php echo $drank->getBestandsnaam(); ?>" alt="<?php echo $drank->getNaam(); ?>" >            
                <?php
              } else {
                ?>    
                <a  href="./selecteerDrank.php?action=select&amp;id=<?php echo $drank->getId(); ?>">
                  <img class="genoegsaldo" src="img/<?php echo $drank->getBestandsnaam(); ?>" alt="<?php echo $drank->getNaam(); ?>">
                </a>
                <?php
              }
              ?>
            </div> <!-- EINDE CONTAINER DRANKINTERFACE -->

            <!-- CONTAINER DRANKINFO -->
            <div class="drankinfo center" style="<?php echo $uitverkocht ? "color: red" : "color:white" ?>">
              <?php echo $uitverkocht ? "uitverkocht" : sprintf("%01.2f", $drank->getPrijs() / 10) . " €"; ?>
            </div> <!-- ECHO CONTAINER DRANKINFO -->


          </div> <!-- EINDE CONTAINER DRANK -->
          <?php
        }
        ?>
      </section> <!-- EINDE CONTAINER VOOR DE DRANKEN -->

      <!-- MUNTCONTAINER  -->
      <section id="muntdisplay">  

        <div id="muntenweergave">
          <p class="center">Werp muntstukken in</p>
          <table class="center">
            <tr>
              <th>Munten</th> 
              <th>Wisselgeld</th>
            </tr>
            <?php
            foreach ($munten as $munt) {
              ?>
              <tr>
                <td>                  
                  <a href="voegCreditsToe.php?action=insertcreds&amp;id=<?php echo $munt->getId(); ?>">
                    <img src="img/<?php echo $munt->getOmschrijving(); ?>.png" alt="<?php echo $munt->getOmschrijving(); ?>">
                  </a>
                </td>

                <td><?php echo $munt->getIngeworpen(); ?></td>
              </tr>
              <?php
            }
            ?>
          </table>
          <p class="totaal">Totaal : <?php echo sprintf("%01.2f", $muntSrvc->geefTotaalIngeworpen() / 10); ?> &euro;</p>
        </div>

        <!-- EJECT MUNTEN-->
        <div id="ejectmunten" class="center">          
          <a href="geefWissel.php?action=wissel">Geef wisselgeld / geef terug</a>
        </div> <!-- EINDE EJECT MUNTEN -->

      </section> <!-- EINDE MUNTCONTAINER-->


    </div> <!-- EINDE WRAPPER -->
    
  </body>
</html>
