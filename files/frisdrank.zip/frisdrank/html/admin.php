<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <title>Frisdrankautomaat</title>
    <link href="css/drankautomaat.css" rel="stylesheet">
    <!--[if lt IE 9]>
    <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->
  </head>  
  <body>
    <header class="schaduw">
      <div id="logon">
        Welkom, <?php echo $_SESSION["gebruiker"]; ?>        
        <a href="adminPage.php?action=afmelden">Afmelden</a>
      </div>
    </header>
    <!-- WRAPPER  -->
    <div id="wrapper" class="schaduw">

      <section id="drankdisplay"> <!-- CONTAINER VOOR DE DRANKEN -->
        <?php
        foreach ($dranken as $drank) {
          $aantal = $drank->getAantal();
          $genoegSaldo = $muntSrvc->geefTotaalIngeworpen() >= $drank->getPrijs();
          ?> 

          <!-- CONTAINER DRANK -->
          <div class="drankcell vlotlinks"> 

            <!-- CONTAINER DRANKINTERFACE -->
            <div> 
              <img src="img/<?php echo $drank->getBestandsnaam(); ?>" alt="<?php echo $drank->getNaam(); ?>" >            
            </div> <!-- EINDE CONTAINER DRANKINTERFACE -->

            <!-- CONTAINER DRANKINFO -->
            <div class="drankinfo center" style="<?php echo $aantal == 0 ? "color: red" : "color:white" ?>">
              <p><?php echo $aantal; ?></p>              

              <?php if ($aantal < 20) { ?>
                <a class="vlotlinks" href="vulDrankAan.php?action=vulaan&id=<?php echo $drank->getId(); ?>&aantal=1">+1</a>
                <a href="vulDrankAan.php?action=vulaan&id=<?php echo $drank->getId(); ?>&aantal=5">+5</a>
                <a class="vlotrechts" href="vulDrankAan.php?action=vulaan&id=<?php echo $drank->getId(); ?>&aantal=max">max</a>
                <?php
              } else {
                ?><a class="vol">VOL</a> <?php
              }
              ?>

            </div> <!-- ECHO CONTAINER DRANKINFO -->


          </div> <!-- EINDE CONTAINER DRANK -->
          <?php
        }
        ?>
      </section> <!-- EINDE CONTAINER VOOR DE DRANKEN -->

      <section id="muntdisplay">  

        <div id="muntenweergave">

          <table class="center">
            <tr>
              <th>Munten</th>
              <th></th>
              <th>Aantal</th>
            </tr>
            <?php
            foreach ($munten as $munt) {
              ?>
              <tr>
                <td>                  

                  <img src="img/<?php echo $munt->getOmschrijving(); ?>.png" alt="<?php echo $munt->getOmschrijving(); ?>">

                </td>
                <td> X </td>
                <td><?php echo $munt->getAantal() ?></td>
              </tr>
              <?php
            }
            ?>
          </table>
          <p class="totaal">Totaal : <?php echo sprintf("%01.2f", $muntSrvc->totaalGeldInAutomaat() / 10); ?> &euro;</p>
        </div>

        <!-- EJECT MUNTEN-->
        <div id="ejectmunten" class="center">          
          <a href="leegLade.php?action=leeg">Maak geldlade leeg</a>
        </div> <!-- EINDE EJECT MUNTEN -->

      </section> <!-- EINDE MUNTCONTAINER-->
    </div>

  </body>
</html>
