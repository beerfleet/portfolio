<?php

use VDAB\Frisdrank\Business\DrankService;
use Doctrine\Common\ClassLoader;

require_once './Doctrine/Common/ClassLoader.php';

$classloader = new ClassLoader("VDAB", "src");
$classloader->register();

if (isset($_GET["action"]) && $_GET["action"] == "vulaan") {  
  $aantal = $_GET["aantal"];
  $drankSrvc = new DrankService();
  $drankSrvc->voegAantalToe($aantal);  
  header("Location: adminPage.php");
  exit(0);
} else {
  header("Location: index.php");
  exit(0);
}