<?php

use VDAB\Frisdrank\Entities\Gebruiker;
use VDAB\Frisdrank\Data\GebruikerDAO;
use VDAB\Frisdrank\Lib\BCrypt;
use Doctrine\Common\ClassLoader;

require_once './Doctrine/Common/ClassLoader.php';

$classloader = new ClassLoader("VDAB", "src");
$classloader->register();

try {
  $crypto = new BCrypt();
  $passwordHash = $crypto->password_hash("griffin", PASSWORD_DEFAULT);
  $gebruiker = new Gebruiker("peter", $passwordHash);
  $gebruikerDAO = new GebruikerDAO();
  $gebruikerDAO->addUser($gebruiker);
} catch (PDOException $ex) {
  echo $ex->getMessage();
} catch (Exception $ex) {
  echo $ex->getMessage();
}