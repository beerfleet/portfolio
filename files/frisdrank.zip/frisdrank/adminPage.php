<?php

use VDAB\Frisdrank\Business\GebruikerService;
use VDAB\Frisdrank\Business\DrankService;
use VDAB\Frisdrank\Business\MuntService;
use Doctrine\Common\ClassLoader;

require_once './Doctrine/Common/ClassLoader.php';
$classloader = new ClassLoader("VDAB", "src");
$classloader->register();

session_start();

try {

  /* afmelden */
  if (isset($_GET["action"]) && $_GET["action"] == "afmelden") {
    session_destroy();
    header("Location: index.php");
    exit(0);
  }

  /* juiste credentials */
  if (isset($_POST["username"]) && isset($_POST["password"])) {
    $naam = $_POST["username"];
    $paswoord = $_POST["password"];
    $gebruikerSrvc = new GebruikerService();
    if ($gebruikerSrvc->verifieerGebruiker($naam, $paswoord)) {
      $_SESSION["gebruiker"] = $naam;

      $drankSrvc = new DrankService();
      $dranken = $drankSrvc->geefAlleDranken();
      $muntSrvc = new MuntService();
      $munten = $muntSrvc->geefMuntenDesc();
      include './html/admin.php';
    } else {
      $ongeldigeLogin = true;
      include './index.php';
    }
    /* session bestaat al */
  } else if (isset($_SESSION["gebruiker"])) {
    $naam = $_SESSION["gebruiker"];

    $drankSrvc = new DrankService();
    $dranken = $drankSrvc->geefAlleDranken();
    $muntSrvc = new MuntService();
    $munten = $muntSrvc->geefMuntenDesc();
    include './html/admin.php';

    /* kan niet aanmelden zonder credentials */
  } else {
    header("Location: index.php");
    exit(0);
  }
} catch (PDOException $ex) {
  echo $ex->getMessage();
} catch (Exception $ex) {
  echo $ex->getMessage();
}