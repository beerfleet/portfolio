<?php

use VDAB\Frisdrank\Business\MuntService;
use Doctrine\Common\ClassLoader;

require_once './Doctrine/Common/ClassLoader.php';

$classloader = new ClassLoader("VDAB", "src");
$classloader->register();

try {
  if (isset($_GET["action"]) && $_GET["action"] == "wissel") {
    $geldlade = new MuntService();
    $geldlade->geefSaldoTerug();
    include './index.php';
  }
} catch (PDOException $ex) {
  echo $ex->getMessage();
} catch (Exception $ex) {
  echo $ex->getMessage();
}