<?php
 




/* VOEG USER TOE  * 
 */
try {
  $crypto = new BCrypt();
  $passwordHash = $crypto->password_hash("griffin", PASSWORD_DEFAULT);
  $gebruiker = new Gebruiker("peter", $passwordHash);
  $gebruikerDAO = new GebruikerDAO();
  $gebruikerDAO->addUser($gebruiker);
} catch (PDOException $ex) {
  echo $ex->getMessage();
}


/* CONTROLEER PASWOORD 

try {
  $password = "Appel.Sap";  
  $gebruikerDAO = new GebruikerDAO();
  $user = $gebruikerDAO->getUserByNaam("admin");
  $test = password_verify($password, $user->getPaswoord());

  echo !$test ? "Fout paswoord" : "OK";
 
  
} catch (PDOException $ex) {
  echo $ex->getMessage();
} catch (Exception $ex) {
  echo $ex->getMessage();
}
 */