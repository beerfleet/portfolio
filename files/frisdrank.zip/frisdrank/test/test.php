<?php

require_once './Data/MuntDAO.php';
require_once './Entities/Teruggave.php';
require_once './Entities/MuntenIterator.php';

$muntDAO = new MuntDAO();
$munten = $muntDAO->getMuntenDesc();
$bedrag = 43;
$teruggave = new Teruggave($munten, $bedrag);
echo $teruggave->kanTeruggeven() ? "Kan Teruggeven " : " Kan niet teruggeven";


/*

echo "<pre>";
print_r($teruggave);
echo "</pre>";

*/