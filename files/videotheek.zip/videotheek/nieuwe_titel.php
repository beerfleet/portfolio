<?php

if (!isset($_SESSION["user"]))
  session_start();

use Doctrine\Common\ClassLoader;
use VDAB\Videotheek\Business\FilmService;

require_once './Doctrine/Common/ClassLoader.php';

$classloader = new ClassLoader("VDAB", "src");
$classloader->register();

if (isset($_SESSION["user"])) {
  try {
    if (isset($_POST["titel"]) && !empty($_POST["titel"])) {
      $titel = filter_input(INPUT_POST, "titel");
      $filmSrvc = new FilmService($titel);
      $filmSrvc->voegTitelToe($titel);
    }
    include "./html/nieuwe_titel.html";
  } catch (Exception $ex) {
    $err_message = $ex->getCode() == '23000' ? "$titel bestaal al" : $err_message = $ex->getMessage();
    unset($titel);
    include "./html/nieuwe_titel.html";
  }
} else {
  include './html/logon.html';
}

