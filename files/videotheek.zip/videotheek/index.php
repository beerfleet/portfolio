<?php

if (!session_id())
  session_start();

use Doctrine\Common\ClassLoader;

require_once './Doctrine/Common/ClassLoader.php';

$classloader = new ClassLoader("VDAB", "src");
$classloader->register();

if (isset($_SESSION["user"])) {

  if (isset($_GET["action"]) && $_GET["action"] == "afmelden") {
    session_destroy();
    header("Location: index.php");
    exit(0);
  }

  include './html/hoofdmenu.html';
} else {
  include './html/logon.html';
}