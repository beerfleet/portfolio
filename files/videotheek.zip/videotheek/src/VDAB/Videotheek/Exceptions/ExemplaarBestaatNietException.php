<?php

namespace VDAB\Videotheek\Exceptions;
use Exception;

class ExemplaarBestaatNietException extends Exception {
  //put your code here
}
