<?php

namespace VDAB\Videotheek\Exceptions;
use Exception;

class DVDverhuurException extends Exception { 
  
}
