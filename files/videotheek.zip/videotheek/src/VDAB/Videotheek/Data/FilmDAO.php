<?php

namespace VDAB\Videotheek\Data;

use VDAB\Videotheek\Entities\Film;
use VDAB\Videotheek\Entities\DBHelper;
use VDAB\Videotheek\Exceptions\DataHandlerException;

class FilmDAO {

  public function haalTitelsOp() {
    $films = array();
    $sql = "SELECT id, titel FROM films";
    try {
      $dbh = DBHelper::connect();
      $film_rs = $dbh->query($sql);
      $dbh = null;
      foreach ($film_rs as $film) {
        $films[] = Film::create($film["id"], $film["titel"]);
      }
      return $films;
    } catch (PDOException $ex) {
      throw new DataHandlerException($ex);
    }
  }

  public function voegTitelToe($titel) {
    $sql = "INSERT INTO films (titel) VALUES ('" . $titel . "')";
    try {
      $dbh = DBHelper::connect();
      $dbh->exec($sql);
      $dbh = null;
    } catch (PDOException $ex) {
      throw new DataHandlerException($ex);
    }
  }

  public function verwijderTitel($id) {
    $sql = "DELETE FROM films WHERE id=" . $id;
    try {
      $dbh = DBHelper::connect();
      $dbh->exec($sql);
      $dbh = null;
    } catch (PDOException $ex) {
      throw new DataHandlerException($ex);
    }
  }

}
