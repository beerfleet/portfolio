<?php

namespace VDAB\Videotheek\Data;

use VDAB\Videotheek\Entities\Exemplaar;
use VDAB\Videotheek\Entities\DBHelper;
use VDAB\Videotheek\Entities\Film;
use VDAB\Videotheek\Exceptions\DataHandlerException;

class ExemplaarDAO {

  public function haalExemplarenOpMetFilmId($id) {
    $exemplaren = array();
    $sql = "SELECT ex.id as ex_id, film_id, titel, aanwezig "
            . "FROM exemplaren ex, films "
            . "WHERE ex.film_id = films.id "
            . "AND  film_id=" . $id;

    try {
      $dbh = DBHelper::connect();
      $exemplaar_rs = $dbh->query($sql);
      $dbh = null;
      foreach ($exemplaar_rs as $xmplr) {
        $exemplaren[] = Exemplaar::create($xmplr["ex_id"], $xmplr["aanwezig"], Film::create($xmplr["film_id"], $xmplr["titel"]));
      }
      return $exemplaren;
    } catch (PDOException $ex) {
      throw new DataHandlerException($ex);
    }
  }

  public function haalAlleExemplarenJoinFilmsOp() {
    $exemplaren = array();
    $sql = "SELECT ex.id as ex_id, film_id, titel, aanwezig "
            . "FROM exemplaren ex, films "
            . "WHERE ex.film_id = films.id "
            . "ORDER BY titel";
    try {
      $dbh = DBHelper::connect();
      $exemplaar_rs = $dbh->query($sql);
      $dbh = null;
      foreach ($exemplaar_rs as $xmplr) {
        $exemplaren[] = Exemplaar::create($xmplr["ex_id"], $xmplr["aanwezig"], Film::create($xmplr["film_id"], $xmplr["titel"]));
      }
      return $exemplaren;
    } catch (PDOException $ex) {
      throw new DataHandlerException($ex);
    }
  }

  public function haalAlleExemplarenOpSorteerId() {
    $sql = "SELECT id, film_id, aanwezig FROM exemplaren ORDER BY id";
    try {
      $dbh = DBHelper::connect();
      $exemplaar_rs = $dbh->query($sql);
      $dbh = null;
      foreach ($exemplaar_rs as $xmplr) {
        $exemplaren[] = Exemplaar::create($xmplr["id"], $xmplr["aanwezig"]);
      }
      return $exemplaren;
    } catch (PDOException $ex) {
      throw new DataHandlerException($ex);
    }
  }

  public function haalGerelateerdeOp($exemplaar_id) {
    $exemplaren = array();
    $sql = "SELECT ex.id as ex_id, film_id, titel, aanwezig "
            . "FROM exemplaren ex, films "
            . "WHERE film_id = "
            . "(SELECT film_id "
            . "FROM exemplaren "
            . "WHERE id = " . $exemplaar_id . ") "
            . "AND film_id = films.id";
    try {
      $dbh = DBHelper::connect();
      $exemplaar_rs = $dbh->query($sql);
      $dbh = null;
      foreach ($exemplaar_rs as $xmplr) {
        $exemplaren[] = Exemplaar::create($xmplr["ex_id"], $xmplr["aanwezig"], Film::create($xmplr["film_id"], $xmplr["titel"]));
      }
      return $exemplaren;
    } catch (PDOException $ex) {
      throw new DataHandlerException($ex);
    }
  }

  public function haalExemplaarOpMetId($id) {
    $sql = "SELECT id, film_id, aanwezig "
            . "FROM exemplaren "
            . "WHERE id=" . $id;
    try {
      $dbh = DBHelper::connect();
      $exemplaar_rs = $dbh->query($sql);
      $exemplaar = $exemplaar_rs->fetch();
      $dbh = null;
      return $exemplaar;
    } catch (PDOException $ex) {
      throw new DataHandlerException($ex);
    }
  }
  
  public function isExemplaarAanwezig($exemplaar_id) {
    $exemplaar = $this->haalExemplaarOpMetId($exemplaar_id);
    return $exemplaar["aanwezig"] == 1;
  }

  public function voegExemplaarToe($film_id, $exemplaar_id) {
    $sql = "INSERT INTO exemplaren (id, film_id, aanwezig)"
            . "VALUES ($exemplaar_id, $film_id, 1)";

    try {
      $dbh = DBHelper::connect();
      $dbh->exec($sql);
      $dbh = null;
    } catch (PDOException $ex) {
      throw new DataHandlerException($ex);
    }
  }

  public function updateExemplaarToNietAanwezig($exemplaar_id) {
    $sql = "UPDATE exemplaren SET aanwezig=0 WHERE id=$exemplaar_id";
    
    try {
      $dbh = DBHelper::connect();
      $dbh->exec($sql);
      $dbh = null;
    } catch (PDOException $ex) {
      throw new DataHandlerException($ex);
    }
  }
  
  public function updateExemplaarToAanwezig($exemplaar_id) {
    $sql = "UPDATE exemplaren SET aanwezig=1 WHERE id=$exemplaar_id";
    
    try {
      $dbh = DBHelper::connect();
      $dbh->exec($sql);
      $dbh = null;
    } catch (PDOException $ex) {
      throw new DataHandlerException($ex);
    }
  }

  public function verwijderExemplaar($id) {
    $sql = "DELETE FROM exemplaren WHERE id=$id";
    try {
      $dbh = DBHelper::connect();
      $dbh->exec($sql);
      $dbh = null;
    } catch (PDOException $ex) {
      throw new DataHandlerException($ex);
    }
  }

}
