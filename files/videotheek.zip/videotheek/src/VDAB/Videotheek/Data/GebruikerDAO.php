<?php

namespace VDAB\Videotheek\Data;

use VDAB\Videotheek\Entities\Gebruiker;
use VDAB\Videotheek\Entities\DBHelper;

class GebruikerDAO {

  public function haalGebruikerOp($naam) {
    $sql = "SELECT id, naam, wachtwoord FROM gebruikers WHERE naam = '$naam'";
    $dbh = DBHelper::connect();
    $user_rs = $dbh->query($sql);
    $gebruiker = $user_rs->fetch();
    return new Gebruiker($gebruiker["id"], $gebruiker["naam"], $gebruiker["wachtwoord"]);
  }

}
