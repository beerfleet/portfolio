<?php

namespace VDAB\Videotheek\Business;

use VDAB\Videotheek\Data\GebruikerDAO;
use VDAB\Videotheek\Lib\BCrypt;

class GebruikerService {

  public function verifieerGebruiker($naam, $wachtwoord) {
    $gebruikerDAO = new GebruikerDAO();
    $gebruiker = $gebruikerDAO->haalGebruikerOp($naam);
    $crypto = new BCrypt();
    return $crypto->password_verify($wachtwoord, $gebruiker->getWachtwoord());
  }

}
