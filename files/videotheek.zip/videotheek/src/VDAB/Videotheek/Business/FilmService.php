<?php

namespace VDAB\Videotheek\Business;

use VDAB\Videotheek\Data\ExemplaarDAO;
use VDAB\Videotheek\Data\FilmDAO;
use VDAB\Videotheek\Exceptions\DVDverhuurException;
use VDAB\Videotheek\Exceptions\ExemplaarBestaatNietException;
use stdClass;

class FilmService {

  public function geefAlleDVDs() {
    $xmplrDAO = new ExemplaarDAO();
    $xmplr_array = $xmplrDAO->haalAlleExemplarenJoinFilmsOp();
    return $this->maakDTO($xmplr_array);
  }

  public function geefDVDsGerelateerdAan($exemplaarNr) {
    $xmplrDAO = new ExemplaarDAO();
    $xmplr_array = $xmplrDAO->haalGerelateerdeOp($exemplaarNr);
    return $this->maakDTO($xmplr_array);
  }

  public function geefAlleTitels() {
    $filmDAO = new FilmDAO();
    return $filmDAO->haalTitelsOp();
  }

  public function geefAlleExemplaren() {
    $xmplrDAO = new ExemplaarDAO();
    return $xmplrDAO->haalAlleExemplarenOpSorteerId();
  }

  public function voegTitelToe($titel) {
    $filmDAO = new FilmDAO();
    $filmDAO->voegTitelToe($titel);
  }

  public function voegDVDToe($film_id, $exemplaar_id) {
    $xmplrDAO = new ExemplaarDAO();
    $xmplrDAO->voegExemplaarToe($film_id, $exemplaar_id);
  }

  public function verwijderFilm($film_id) {
    $filmDAO = new FilmDAO();
    $filmDAO->verwijderTitel($film_id);
  }

  public function verwijderExemplaar($exemplaar_id) {
    $xmplrDAO = new ExemplaarDAO();
    $xmplrDAO->verwijderExemplaar($exemplaar_id);
  }

  public function verhuurFilm($exemplaar_id) {
    $xmplrDAO = new ExemplaarDAO();

    // exemplaar_nr bestaat niet
    if ($xmplrDAO->haalExemplaarOpMetId($exemplaar_id) == null) {
      throw new ExemplaarBestaatNietException("Onbestaand DVD-nummer ingegeven.");
    }
    
    // check of film nog niet verhuurd is
    if (!$xmplrDAO->isExemplaarAanwezig($exemplaar_id)) {
      throw new DVDverhuurException("DVD-nummer is al verhuurd.");
    }

    // verhuur exemplaar
    $xmplrDAO->updateExemplaarToNietAanwezig($exemplaar_id);
  }
  
  public function brengFilmTerug($exemplaar_id) {
    $xmplrDAO = new ExemplaarDAO();
    
    // exemplaar_nr bestaat niet
    if ($xmplrDAO->haalExemplaarOpMetId($exemplaar_id) == null) {
      throw new ExemplaarBestaatNietException("Onbestaand DVD-nummer ingegeven.");
    }
    
    // check of film nog niet verhuurd is
    if ($xmplrDAO->isExemplaarAanwezig($exemplaar_id)) {
      throw new DVDverhuurException("DVD-nummer is nog niet verhuurd.");
    }
    
    $xmplrDAO->updateExemplaarToAanwezig($exemplaar_id);
  }

  private function maakDTO($exemplaren_array) {
    $dto = new stdClass();
    // splits in films, indexeer met film_id    
    $dto->films = array();
    foreach ($exemplaren_array as $exemplaar) {
      $film = $exemplaar->getFilm();
      $film_id = $film->getId();
      if (!isset($dto->films[$film_id])) {
        $dto->films[$film_id] = $film->getTitel();
      }
      // splits is exemplaren (key), aanwezig (value)
      $exemplaar_id = $exemplaar->getId();
      $dto->exemplaren[$film_id][$exemplaar_id] = $exemplaar->getAanwezig();

      // hou aantal aanwezig bij
      if (isset($dto->telAanwezig[$film_id])) {
        $dto->telAanwezig[$film_id] += $exemplaar->getAanwezig();
      } else {
        $dto->telAanwezig[$film_id] = $exemplaar->getAanwezig();
      }
    }
    return $dto;
  }

}
