<?php

namespace VDAB\Videotheek\Entities;

class Gebruiker {

  private $id;
  private $naam;
  private $wachtwoord;

  function __construct($id, $naam, $wachtwoord) {
    $this->id = $id;
    $this->naam = $naam;
    $this->wachtwoord = $wachtwoord;
  }

  public function getId() {
    return $this->id;
  }

  public function getNaam() {
    return $this->naam;
  }

  public function getWachtwoord() {
    return $this->wachtwoord;
  }

  public function setId($id) {
    $this->id = $id;
  }

  public function setNaam($naam) {
    $this->naam = $naam;
  }

  public function setWachtwoord($wachtwoord) {
    $this->wachtwoord = $wachtwoord;
  }

}
