<?php

namespace VDAB\Videotheek\Entities;

class Film {
  
  private static $idMap = array();

  private $id;
  private $titel;  

  private function __construct($id, $titel) {
    $this->id = $id;
    $this->titel = $titel;
  }
  
  public static function create($id, $titel){
    if (!isset(self::$idMap[$id])) {
      self::$idMap[$id] = new Film($id, $titel);
    }
    return self::$idMap[$id];
  }

  public function getId() {
    return $this->id;
  }

  public function getTitel() {
    return $this->titel;
  }

  public function setId($id) {
    $this->id = $id;
  }

  public function setTitel($titel) {
    $this->titel = $titel;
  }
}
