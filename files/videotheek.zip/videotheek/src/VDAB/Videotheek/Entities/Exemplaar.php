<?php

namespace VDAB\Videotheek\Entities;

class Exemplaar {

  private static $idMap = array();
  private $id;
  private $aanwezig;
  private $film;

  private function __construct($id, $aanwezig, Film $film = null) {
    $this->id = $id;
    $this->aanwezig = $aanwezig;
    $this->film = $film;
  }

  public static function create($id, $aanwezig, Film $film = null) {
    if (!isset(self::$idMap[$id])) {
      self::$idMap[$id] = new Exemplaar($id, $aanwezig, $film);
    }
    return self::$idMap[$id];
  }

  public function getId() {
    return $this->id;
  }

  public function getFilm() {
    return $this->film;
  }

  public function getAanwezig() {
    return $this->aanwezig;
  }

  public function setId($id) {
    $this->id = $id;
  }

  public function setFilm($film) {
    $this->filmId = $film;
  }

  public function setAanwezig($aanwezig) {
    $this->aanwezig = $aanwezig;
  }

}
