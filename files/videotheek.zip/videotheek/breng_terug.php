<?php

if (!isset($_SESSION["user"]))
  session_start();

use Doctrine\Common\ClassLoader;
use VDAB\Videotheek\Business\FilmService;
use VDAB\Videotheek\Exceptions\ExemplaarBestaatNietException;
use VDAB\Videotheek\Exceptions\DVDverhuurException;

require_once './Doctrine/Common/ClassLoader.php';

$classloader = new ClassLoader("VDAB", "src");
$classloader->register();

if (isset($_SESSION["user"])) {
  try {
    $filmSrvc = new FilmService();

    if (isset($_POST["exemplaar_id"])) {
      $exemplaar_id = filter_input(INPUT_POST, "exemplaar_id");
      $filmSrvc->brengFilmTerug($exemplaar_id);
      $filmTerug = true;
    }

    include './html/breng_terug.html';
  } catch (ExemplaarBestaatNietException $ex) {
    $onbestaand = true;
    include './html/breng_terug.html';
  } catch (DVDverhuurException $ex) {
    $nogNietVerhuurd = true;
    include './html/breng_terug.html';
  } catch (Exception $ex) {
    echo $ex->getMessage();
    include './index.php';
  }
} else {
  include './html/logon.html';
}