<?php

if (!isset($_SESSION["user"]))
  session_start();

use Doctrine\Common\ClassLoader;
use VDAB\Videotheek\Business\FilmService;

require_once './Doctrine/Common/ClassLoader.php';
$classloader = new ClassLoader("VDAB", "src");
$classloader->register();

if (isset($_SESSION["user"])) {
  try {
    $filmSrvc = new FilmService();
    if (isset($_POST["exemplaar_id"])) {
      if (isset($_POST["film_id"])) {
        if (is_numeric($_POST["exemplaar_id"])) {
          $film_id = filter_input(INPUT_POST, "film_id");
          $exemplaar_id = filter_input(INPUT_POST, "exemplaar_id");
          $filmSrvc->voegDVDToe($film_id, $exemplaar_id);
          $toegevoegd = true;
        } else {
          $ongeldigeInvoer = true;
        }
      } else {
        $nietToegevoegd = true;
      }
    }
    $titels = $filmSrvc->geefAlleTitels();
    include './html/nieuw_exemplaar.html';
  } catch (Exception $ex) {
    if ($ex->getCode() == '23000') {
      $dvdNummerBestaat = true;
      $titels = $filmSrvc->geefAlleTitels();
      include './html/nieuw_exemplaar.html';
    } else {
      echo $ex->getMessage();
      include './index.php';
    }
  }
} else {
  include './html/logon.html';
}
