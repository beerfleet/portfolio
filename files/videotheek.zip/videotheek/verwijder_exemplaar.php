<?php

if (!isset($_SESSION["user"]))
  session_start();

use Doctrine\Common\ClassLoader;
use VDAB\Videotheek\Business\FilmService;

require_once './Doctrine/Common/ClassLoader.php';

$classloader = new ClassLoader("VDAB", "src");
$classloader->register();

if (isset($_SESSION["user"])) {
  try {
    $filmSrvc = new FilmService();
    if (isset($_POST["exemplaar_id"])) {
      $exemplaar_id = filter_input(INPUT_POST, "exemplaar_id");
      $filmSrvc->verwijderExemplaar($exemplaar_id);
      $dvdVerwijderd = true;
    }

    $exemplaren = $filmSrvc->geefAlleExemplaren();
    include './html/verwijder_exemplaar.html';
  } catch (Exception $ex) {
    echo $ex->getMessage();
    include './index.php';
  }
} else {
  include './html/logon.html';
}
