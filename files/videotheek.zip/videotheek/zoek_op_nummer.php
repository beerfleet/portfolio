<?php

if (!isset($_SESSION["user"]))
  session_start();

use Doctrine\Common\ClassLoader;
use VDAB\Videotheek\Business\FilmService;

require_once './Doctrine/Common/ClassLoader.php';

$classloader = new ClassLoader("VDAB", "src");
$classloader->register();

if (isset($_SESSION["user"])) {
  try {
    if (isset($_POST["zoek_id"])) {
      $zoek_id = html_entity_decode($_POST["zoek_id"]);
      if (is_numeric($zoek_id)) {
        $filmSrvc = new FilmService();
        $dvds = $filmSrvc->geefDVDsGerelateerdAan($zoek_id);
        include './html/toon_films.html';
      } else {
        $error = true;
        include "./html/zoek_op_nummer.html";
      }
    } else {
      include './html/zoek_op_nummer.html';
    }
  } catch (Exception $exc) {
    echo $exc->getMessage();
    include './index.php';
  }
} else {
  include './html/logon.html';
}


