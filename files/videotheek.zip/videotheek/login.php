<?php

if (!session_id())
  session_start();

use Doctrine\Common\ClassLoader;
use VDAB\Videotheek\Business\GebruikerService;

require_once './Doctrine/Common/ClassLoader.php';

$classloader = new ClassLoader("VDAB", "src");
$classloader->register();

if (isset($_POST["gebruiker"])) {
  if (!empty($_POST["gebruiker"])) {
    $gebruiker = filter_input(INPUT_POST, "gebruiker");
    $paswoord = mysql_real_escape_string($_POST["wachtwoord"]);
    $gebruikerSrvc = new GebruikerService();
    if ($gebruikerSrvc->verifieerGebruiker($gebruiker, $paswoord)) {
      $_SESSION["user"] = $gebruiker;
      include './index.php';
    } else {
      $fout = "Aanmelden mislukt";
      include './html/logon.html';
    }
  } else {
    $fout = "geen gebruiker ingegeven";
    include './html/logon.html';
  }
} else {
  $fout = "ongeldige gebruiker";
  include './html/logon.html';
}