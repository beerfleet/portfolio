<?php

if (!isset($_SESSION["user"]))
  session_start();

use Doctrine\Common\ClassLoader;
use VDAB\Videotheek\Business\FilmService;

require_once './Doctrine/Common/ClassLoader.php';

$classloader = new ClassLoader("VDAB", "src");
$classloader->register();

if (isset($_SESSION["user"])) {
  try {
    $filmSrvc = new FilmService();
    if (isset($_POST["film_id"])) {
      $film_id = filter_input(INPUT_POST, "film_id");
      $filmSrvc->verwijderFilm($film_id);
      $filmVerwijderd = true;
    }
    $titels = $filmSrvc->geefAlleTitels();
    include './html/verwijder_titel.html';
  } catch (Exception $ex) {
    echo $ex->getMessage();
    include './index.php';
  }
} else {
  include './html/logon.html';
}


