<?php

use Doctrine\Common\ClassLoader;
use VDAB\Videotheek\Business\FilmService;
use VDAB\Videotheek\Data\FilmDAO;
use VDAB\Videotheek\Data\ExemplaarDAO;
use VDAB\Videotheek\Entities\DBHelper;
use VDAB\Videotheek\Lib\BCrypt;

require_once './Doctrine/Common/ClassLoader.php';

$classloader = new ClassLoader("VDAB", "src");
$classloader->register();


/* FilmDAO 
  try {
  $filmDAO = new FilmDAO();
  $filmDAO->voegTitelToe("king kong");
  echo "<pre>";
  print_r($film);
  echo "</pre>";
  } catch (Exception $ex) {
  echo $ex->getMessage();
  }
 */

/*  FilmService  
  try {

  $filmSrvc = new FilmService();
  //echo $exemplaarSrvc->dvdBestaat(6) ? "HET BESTAAT" : "BESTAAT NIET";
  $exemplaren = $filmSrvc->geefAlleDVDs();
  echo "<pre>";
  print_r($exemplaren);
  echo "</pre>";
  } catch (Exception $ex) {
  echo $ex->getMessage();
  }
 */


/* ExemplaarDAO 
try {
  $exemplaarDAO = new ExemplaarDAO();
  echo $exemplaarDAO->isExemplaarAanwezig(4) == null ? "NULL" : "AANWEZIG";
  //echo $exemplaarDAO->haalExemplaarOpMetId(-6) == null ? "NULL" : "OK";
  echo "<pre>";
  //print_r($exemplaren);
  echo "</pre>";
} catch (Exception $ex) {
  echo $ex->getMessage();
}
 */

/*Insert users in DB */
function voegUserToe($naam, $paswoord) {
  $bcrypt = new BCrypt();
  $pasw_crypt = $bcrypt->password_hash($paswoord, PASSWORD_DEFAULT);
  $sql = "INSERT INTO gebruikers (naam, wachtwoord) VALUES ('$naam', '$pasw_crypt')";
  $dbh = DBHelper::connect();
  $dbh->exec($sql);
  $dbh = null;
}

voegUserToe("peter", "griffin");
voegUserToe("homer", "simpson");
voegUserToe("jack", "russell");
voegUserToe("appel", "sap");
voegUserToe("lisa", "simpson");
 