<?php

if (!isset($_SESSION["user"]))
  session_start();

use Doctrine\Common\ClassLoader;
use VDAB\Videotheek\Business\FilmService;

require_once './Doctrine/Common/ClassLoader.php';

$classloader = new ClassLoader("VDAB", "src");
$classloader->register();

if (isset($_SESSION["user"])) {
  try {
    $filmSrvc = new FilmService();
    $dvds = $filmSrvc->geefAlleDVDs();
    include './html/toon_films.html';
  } catch (PDOException $ex) {
    echo $ex->getMessage();
    include './index.php';
  }
} else {
  include './html/logon.html';
}



