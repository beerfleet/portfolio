<?php

use Doctrine\Common\ClassLoader;
use VDAB\Broodjes\Business\RegistratieService;
use VDAB\Broodjes\Exceptions\EmailAdresException;

require_once './Doctrine/Common/ClassLoader.php';

$classloader = new ClassLoader("VDAB", "src");
$classloader->register();


try {  
  if (isset($_POST["email"])) {
    $email = filter_input(INPUT_POST, "email");
    $regSrvc = new RegistratieService();
    $regSrvc->resetPaswoord($email);
    $paswoorGereset = true;
  } 
  include './html/nieuw_wachtwoord.html';
} catch (EmailAdresException $ex) {
  $emailErr = $ex->getMessage();
  include './html/nieuw_wachtwoord.html';
} catch (Exception $ex) {
  $errBoodschap = $ex->getMessage();
  include './html/nieuw_wachtwoord.html';
}
