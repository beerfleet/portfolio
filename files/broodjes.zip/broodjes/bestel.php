<?php

use Doctrine\Common\ClassLoader;
use VDAB\Broodjes\Business\OrderService;
use VDAB\Broodjes\Exceptions\BestellingException;

require_once './Doctrine/Common/ClassLoader.php';

$classloader = new ClassLoader("VDAB", "src");
$classloader->register();


try {
  if (!session_id())
    session_start();
  
  if (isset($_SESSION["cursist"])) {
    $cursist = $_SESSION["cursist"];
    $orderSrvc = new OrderService();    
    $items = $orderSrvc->checkBestellingEnGeefItems($cursist->getId());
    if (isset($_SESSION["broodjes"])) {
      $displayMand["broodjes"] = $_SESSION["broodjes"];
    }
    include './html/bestel.html';    
  } else {
    header("Location: ./login.php");
    exit(0);
  }
  
} catch (BestellingException $ex) {  
  $code = $ex->getCode();
  switch ($code) {
    case 1: // Bestelling gemaakt
      header("Location: ./overzicht.php");
      exit(0);
    case 2: // Kan niet meer bestellen
      include './html/onbeschikbaar.html';
      break;   
  }

} catch (Exception $ex) {
  include './fallback_login_inc.php';
}