<?php

use Doctrine\Common\ClassLoader;

require_once './Doctrine/Common/ClassLoader.php';

$classloader = new ClassLoader("VDAB", "src");
$classloader->register();


try {  
  if (!session_id())
    session_start();
  /*Ingelogd ?*/
  if (isset($_SESSION["cursist"])) {
    
    if (isset($_GET["id"])) {
      $broodje_index = filter_input(INPUT_GET, "id");
      unset($_SESSION["broodjes"][$broodje_index]);      
    }
    header("Location: ./bestel.php");
    exit(0);    
  } else {
    header("Location: index.php");
    exit(0);
  }
} catch (Exception $ex) {  
  include './fallback_login_inc.php';
}