<?php

use Doctrine\Common\ClassLoader;
use VDAB\Broodjes\Business\RegistratieService;

require_once './Doctrine/Common/ClassLoader.php';

$classloader = new ClassLoader("VDAB", "src");
$classloader->register();


try {
  if (isset($_POST["vnaam"])) {

    $email = filter_input(INPUT_POST, "email", FILTER_VALIDATE_EMAIL);
    $vnaam = filter_input(INPUT_POST, "vnaam");
    $trim_vnaam = trim($vnaam);
    $anaam = filter_input(INPUT_POST, "anaam");
    $trim_anaam = trim($anaam);

    $err = false;
    if (!$email) {
      $emailErr = true;
      $err = true;
    }
    if (empty($trim_vnaam)) {
      $vNaamErr = true;
      $err = true;
    }
    if (empty($trim_anaam)) {
      $aNaamErr = true;
      $err = true;
    }

    if ($err) {
      include './html/registreer.html';
    } else {
      $regSrvc = new RegistratieService();
      $regSrvc->registreer($email, $vnaam, $anaam);
      $mailVerstuurd = true;
      include './html/login.html';
    }
  } else {
    include './html/registreer.html';
  }
} catch (Exception $ex) {
  $errBoodschap = $ex->getMessage();
  include './html/registreer.html';
}