<?php

use Doctrine\Common\ClassLoader;
use VDAB\Broodjes\Business\OrderService;

require_once './Doctrine/Common/ClassLoader.php';

$classloader = new ClassLoader("VDAB", "src");
$classloader->register();


try {
  if (!session_id())
    session_start();
  
  /*Ingelogd ?*/
  if (isset($_SESSION["cursist"])) {
    
    /*broodje meegegeven van vorige pagina ?*/
    if (isset($_GET["id"])) {
      $broodje_index = filter_input(INPUT_GET, "id");
      $orderSrvc = new OrderService();
      
      // Voeg broodje toe aan session, als broodje bestaat
      $broodje = $orderSrvc->voegBroodjeToe($broodje_index);
      if ($broodje != null) {
        $_SESSION["broodjes"][] = $broodje;
      }
    }
    header("Location: ./bestel.php");
    exit(0);
  } else {
    header("Location: ./index.php");
    exit(0);
  }
} catch (Exception $ex) {
  include './fallback_login_inc.php';
}