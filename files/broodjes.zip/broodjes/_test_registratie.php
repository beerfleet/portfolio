<?php

use Doctrine\Common\ClassLoader;
use VDAB\Broodjes\Business\RegistratieService;

require_once './Doctrine/Common/ClassLoader.php';

$classloader = new ClassLoader("VDAB", "src");
$classloader->register();


try {
  $regSrvc = new RegistratieService();
  $cursist = $regSrvc->resetPaswoord($email);  
  
} catch (Exception $ex) {
  echo $ex->getMessage();
}