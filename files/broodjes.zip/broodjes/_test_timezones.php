<?php

use Doctrine\Common\ClassLoader;

require_once './Doctrine/Common/ClassLoader.php';

$classloader = new ClassLoader("VDAB", "src");
$classloader->register();


try {
  $tijdString = date('H:i', time());
  if ($tijdString > '07:00' && $tijdString <= '09:59') {
    echo $tijdString . " IS BINNEN DE TIJD";
  } else {
    echo $tijdString . " IS NIET BINNEN DE TIJD";
  }
} catch (Exception $ex) {
  echo $ex->getMessage();
}

