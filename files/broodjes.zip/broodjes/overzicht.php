<?php

use Doctrine\Common\ClassLoader;
use VDAB\Broodjes\Business\OrderService;
use VDAB\Broodjes\Exceptions\BestellingException;

require_once './Doctrine/Common/ClassLoader.php';


$classloader = new ClassLoader("VDAB", "src");
$classloader->register();

try {
  if (!session_id())
    session_start();
  if (isset($_SESSION["cursist"])) {
    $cursist = $_SESSION["cursist"];
    $orderSrvc = new OrderService();
    $order = $orderSrvc->geefOrderVanCursist($cursist->getId());
    include './html/overzicht.html';
  } else {
    include './html/login.html';
  }
} catch (BestellingException $ex) {
  header("Location: bestel.php");
  exit(0);
} catch (Exception $ex) {
  include './fallback_login_inc.php';
}