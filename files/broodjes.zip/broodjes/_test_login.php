<?php

use Doctrine\Common\ClassLoader;
use VDAB\Broodjes\Data\CursistDAO;
use VDAB\Broodjes\Lib\BCrypt;

require_once './Doctrine/Common/ClassLoader.php';

$classloader = new ClassLoader("VDAB", "src");
$classloader->register();


try {
  $paswoord = "7jlf";
  $email = "janvb@pandora.be";
  
  $cursistDAO = new CursistDAO();
  $cursist = $cursistDAO->zoekCursistOpEmail($email);  
  
  $crypto = new BCrypt();
  $resultaat = $crypto->password_verify($paswoord, $cursist->getPaswoord());
  
  echo $resultaat == null ? "NIET CORRECT" : "CORRECT";
  
} catch (Exception $ex) {
  echo $ex->getMessage();
}