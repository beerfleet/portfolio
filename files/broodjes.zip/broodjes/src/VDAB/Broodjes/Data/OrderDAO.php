<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace VDAB\Broodjes\Data;

use VDAB\Broodjes\Entities\Broodje;
use VDAB\Broodjes\Entities\Beleg;
use VDAB\Broodjes\Entities\DBHelper;
use VDAB\Broodjes\Exceptions\DataSourceException;
use VDAB\Broodjes\Exceptions\DataLaagException;
use PDOException;
use PDO;

/**
 * Description of OrderDAO
 *
 * @author Kukulkan
 */
class OrderDAO {

  // broodjes
  public function geefBroodjes() {
    try {
      $broodjes = array();
      $sql = "SELECT id, naam, prijs FROM broodjes ORDER BY naam";
      $dbh = DBHelper::connect();
      $broodjes_rs = $dbh->query($sql);
      foreach ($broodjes_rs as $broodje) {
        $broodjes[$broodje["id"]] = Broodje::create($broodje["id"], $broodje["naam"], $broodje["prijs"]);
      }
      return $broodjes;
      $dbh = null;
    } catch (PDOException $ex) {
      $code = $ex->getCode();
      switch ($code) {
        case "2002": /* Geen DB connectie */
        case "1049": /* Onbekende Database */
        case "1045": /* Ongeldige credentials */
        case "1044": /* Access denied */
          throw new DataSourceException("Kan geen toegang tot de gegevens krijgen.");
        default:
          throw new DataLaagException("Er was een onvoorzien probleem met de toegang tot de gegevens");
      }
    }
  }

  public function zoekBroodjeMetId($id) {
    try {
      $sql = "SELECT id, naam, prijs FROM broodjes WHERE id = ?";
      $dbh = DBHelper::connect();
      $sth = $dbh->prepare($sql);
      $sth->bindParam(1, $id, PDO::PARAM_INT);
      $sth->execute();
      $broodje = $sth->fetch();
      return Broodje::create($broodje["id"], $broodje["naam"], $broodje["prijs"]);
      $dbh = null;
    } catch (PDOException $ex) {
      $code = $ex->getCode();
      switch ($code) {
        case "2002": /* Geen DB connectie */
        case "1049": /* Onbekende Database */
        case "1045": /* Ongeldige credentials */
        case "1044": /* Access denied */
          throw new DataSourceException("Kan geen toegang tot de gegevens krijgen.");
        default:
          throw new DataLaagException("Er was een onvoorzien probleem met de toegang tot de gegevens");
      }
    }
  }

  //beleg
  public function geefBeleg() {
    try {
      $beleg_rij = array();
      $sql = "SELECT id, naam, prijs FROM beleg ORDER BY naam";
      $dbh = DBHelper::connect();
      $beleg_rs = $dbh->query($sql);
      foreach ($beleg_rs as $beleg) {
        $beleg_rij[$beleg["id"]] = Beleg::create($beleg["id"], $beleg["naam"], $beleg["prijs"]);
      }
      return $beleg_rij;
      $dbh = null;
    } catch (PDOException $ex) {
      $code = $ex->getCode();
      switch ($code) {
        case "2002": /* Geen DB connectie */
        case "1049": /* Onbekende Database */
        case "1045": /* Ongeldige credentials */
        case "1044": /* Access denied */
          throw new DataSourceException("Kan geen toegang tot de gegevens krijgen.");
        default:
          throw new DataLaagException("Er was een onvoorzien probleem met de toegang tot de gegevens");
      }
    }
  }

  public function zoekBelegMetId($id) {
    try {
      $sql = "SELECT id, naam, prijs FROM beleg WHERE id = ?";
      $dbh = DBHelper::connect();
      $sth = $dbh->prepare($sql);
      $sth->bindParam(1, $id, PDO::PARAM_INT);
      $sth->execute();
      $beleg = $sth->fetch();
      return Beleg::create($beleg["id"], $beleg["naam"], $beleg["prijs"]);
      $dbh = null;
    } catch (PDOException $ex) {
      $code = $ex->getCode();
      switch ($code) {
        case "2002": /* Geen DB connectie */
        case "1049": /* Onbekende Database */
        case "1045": /* Ongeldige credentials */
        case "1044": /* Access denied */
          throw new DataSourceException("Kan geen toegang tot de gegevens krijgen.");
        default:
          throw new DataLaagException("Er was een onvoorzien probleem met de toegang tot de gegevens");
      }
    }
  }

  // orders
  public function zoekOrderIdVanVandaag($cursist_id) {
    try {
      $datum = date("Y-m-d");
      $sql = "SELECT id, datum cursist_id FROM orders WHERE datum = ? AND cursist_id = ?";
      $dbh = DBHelper::connect();

      $sth = $dbh->prepare($sql);
      $sth->bindParam(1, $datum, PDO::PARAM_STR);
      $sth->bindParam(2, $cursist_id, PDO::PARAM_INT);
      $sth->execute();
      $order = $sth->fetch();
      return $order["id"];
    } catch (PDOException $ex) {
      $code = $ex->getCode();
      switch ($code) {
        case "2002": /* Geen DB connectie */
        case "1049": /* Onbekende Database */
        case "1045": /* Ongeldige credentials */
        case "1044": /* Access denied */
          throw new DataSourceException("Kan geen toegang tot de gegevens krijgen.");
        default:
          throw new DataLaagException("Er was een onvoorzien probleem met de toegang tot de gegevens");
      }
    }
  }

  public function voegOrderToe($datum, $cursist_id) {
    try {
      $sql = "INSERT INTO orders (datum, cursist_id) VALUES (?, ?)";
      $dbh = DBHelper::connect();
      $sth = $dbh->prepare($sql);
      $sth->bindParam(1, $datum, PDO::PARAM_STR);
      $sth->bindParam(2, $cursist_id, PDO::PARAM_INT);
      $sth->execute();
      $dbh = null;
    } catch (PDOException $ex) {
      $code = $ex->getCode();
      switch ($code) {
        case "2002": /* Geen DB connectie */
        case "1049": /* Onbekende Database */
        case "1045": /* Ongeldige credentials */
        case "1044": /* Access denied */
          throw new DataSourceException("Kan geen toegang tot de gegevens krijgen.");
        default:
          throw new DataLaagException("Er was een onvoorzien probleem met de toegang tot de gegevens");
      }
    }
  }

  public function voegOrderLijnToe($order_id, $order_nr, $broodje_id, $beleg_id) {
    try {
      $sql = "INSERT INTO orderlijnen (order_id, order_nr, broodje_id, beleg_id) VALUES (?, ?, ?, ?)";
      $dbh = DBHelper::connect();
      $sth = $dbh->prepare($sql);
      $sth->bindParam(1, $order_id, PDO::PARAM_INT);
      $sth->bindParam(2, $order_nr, PDO::PARAM_INT);
      $sth->bindParam(3, $broodje_id, PDO::PARAM_INT);
      $sth->bindParam(4, $beleg_id, PDO::PARAM_INT);
      $sth->execute();
      $dbh = null;
    } catch (PDOException $ex) {
      $code = $ex->getCode();
      switch ($code) {
        case "2002": /* Geen DB connectie */
        case "1049": /* Onbekende Database */
        case "1045": /* Ongeldige credentials */
        case "1044": /* Access denied */
          throw new DataSourceException("Kan geen toegang tot de gegevens krijgen.");
        default:
          throw new DataLaagException("Er was een onvoorzien probleem met de toegang tot de gegevens");
      }
    }
  }

  public function haalOrderOp($cursist_id) {
    try {
      $datum = date('Y-m-d');
      $sql = "SELECT CN.id as cursist_id, OL.order_id, OL.order_nr, "
              . "BR.id as broodje_id, BR.naam as broodje, BR.prijs as prijs_broodje, "
              . "BE.id as beleg_id, BE.naam as beleg, BE.prijs as prijs_beleg "
              . "FROM orders OS, cursisten CN, orderlijnen OL "
              . "INNER JOIN broodjes BR ON (BR.id = OL.broodje_id) "
              . "LEFT JOIN beleg BE ON (BE.id = OL.beleg_id) "
              . "WHERE CN.id = ? AND OS.datum = ? "
              . "AND OS.cursist_id = CN.id "
              . "AND OL.order_id = OS.id";
      $dbh = DBHelper::connect();
      $sth = $dbh->prepare($sql);
      $sth->bindParam(1, $cursist_id, PDO::PARAM_INT);
      $sth->bindParam(2, $datum, PDO::PARAM_STR);
      
      $sth->execute();
      $dbh = null;
      return $sth->fetchAll();
    } catch (PDOException $ex) {
      $code = $ex->getCode();
      switch ($code) {
        case "2002": /* Geen DB connectie */
        case "1049": /* Onbekende Database */
        case "1045": /* Ongeldige credentials */
        case "1044": /* Access denied */
          throw new DataSourceException("Kan geen toegang tot de gegevens krijgen.");
        default:
          //echo $ex->getMessage();
          throw new DataLaagException("Er was een onvoorzien probleem met de toegang tot de gegevens");
      }
    }
  }

}
