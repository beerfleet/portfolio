<?php

namespace VDAB\Broodjes\Data;

use VDAB\Broodjes\Entities\DBHelper;
use VDAB\Broodjes\Entities\Cursist;
use VDAB\Broodjes\Exceptions\DataLaagException;
use VDAB\Broodjes\Exceptions\EmailAdresException;
use VDAB\Broodjes\Exceptions\DataSourceException;
use PDOException;
use PDO;

class CursistDAO {

  public function voegCursistToe($vnaam, $anaam, $email, $paswoord) {
    try {
      $dbh = DBHelper::connect();
      $sql = "INSERT INTO cursisten (vnaam, anaam, email, paswoord) "
              . "VALUES (?, ?, ?, ?)";
      $sth = $dbh->prepare($sql);
      $sth->bindParam(1, $vnaam, PDO::PARAM_STR, 45);
      $sth->bindParam(2, $anaam, PDO::PARAM_STR, 45);
      $sth->bindParam(3, $email, PDO::PARAM_STR, 45);
      $sth->bindParam(4, $paswoord, PDO::PARAM_STR, 60);
      $sth->execute();
      $dbh = null;
    } catch (PDOException $ex) {      
      $code = $ex->getCode();
      switch ($code) {
        case "23000":
          throw new EmailAdresException("Email-adres bestaat al.");
        case "2002": /* Geen DB connectie */
        case "1049": /* Onbekende Database */
        case "1045": /* Ongeldige credentials */
        case "1044": /* Access denied */
          throw new DataSourceException("Kan geen toegang tot de gegevens krijgen.");
        default:
          throw new DataLaagException("Er was een onvoorzien probleem met de toegang tot de gegevens");
      }
    }
  }

  public function zoekCursistOpEmail($email) {
    try {
      $dbh = DBHelper::connect();
      $sql = "SELECT id, vnaam, anaam, email, paswoord FROM cursisten WHERE email = ?";
      $sth = $dbh->prepare($sql);
      $sth->bindParam(1, $email, PDO::PARAM_STR, 45);
      $sth->execute();
      $cursist = $sth->fetch();
      return Cursist::create($cursist["id"], $cursist["vnaam"], $cursist["anaam"], $cursist["email"], $cursist["paswoord"]);
      $dbh = null;
    } catch (PDOException $ex) {
      $code = $ex->getCode();
      switch ($code) {
        case "2002": /* Geen DB connectie */
        case "1049": /* Onbekende Database */
        case "1045": /* Ongeldige credentials */
        case "1044": /* Access denied */
          throw new DataSourceException("Kan geen toegang tot de gegevens krijgen.");
        default:
          throw new DataLaagException("Er was een onvoorzien probleem met de toegang tot de gegevens");
      }
    }
  }

  public function updatePaswoord($email, $paswoord) {
    try {
      $dbh = DBHelper::connect();
      $sql = "UPDATE cursisten SET paswoord = ? WHERE email = ?";
      $sth = $dbh->prepare($sql);
      $sth->bindParam(1, $paswoord, PDO::PARAM_STR, 60);
      $sth->bindParam(2, $email, PDO::PARAM_STR, 45);
      $sth->execute();
      $dbh = null;
    } catch (PDOException $ex) {
      $code = $ex->getCode();
      switch ($code) {
        case "2002": /* Geen DB connectie */
        case "1049": /* Onbekende Database */
        case "1045": /* Ongeldige credentials */
        case "1044": /* Access denied */
          throw new DataSourceException("Kan geen toegang tot de gegevens krijgen.");
        default:
          throw new DataLaagException("Er was een onvoorzien probleem met de toegang tot de gegevens");
      }
    }
  }

}
