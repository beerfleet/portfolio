<?php

namespace VDAB\Broodjes\Business;

use VDAB\Broodjes\Exceptions\EmailAdresException;
use VDAB\Broodjes\Lib\BCrypt\BCrypt;
use VDAB\Broodjes\Entities\Paswoord;
use VDAB\Broodjes\Data\CursistDAO;

class RegistratieService {

  public function voegGebruikerToe($vnaam, $anaam, $email, $paswoord) {
    $cursistDAO = new CursistDAO();
    $cursistDAO->voegCursistToe($vnaam, $anaam, $email, $paswoord);
  }

  public function verzendMail($email, $vnaam, $paswoord) {
    $to = $email;
    $subject = "VDAB: registratie broodjesservice";
    $message = "Beste $vnaam," . "\r\n" . "\r\n"
            . "Uw login is $email" . "\r\n"
            . "Uw wachtwoord is $paswoord";
    $headers = "From: noreply@VDAB.be" . "\r\n" .
            "X-Mailer: PHP/" . phpversion();    
    mail($to, $subject, $message, $headers);
  }

  public function registreer($email, $vnaam, $anaam) {
    $paswoord = Paswoord::maak();
    $crypto = new BCrypt();
    $hash = $crypto->password_hash($paswoord, PASSWORD_DEFAULT);
    $this->voegGebruikerToe($vnaam, $anaam, $email, $hash);
    $this->verzendMail($email, $vnaam, $paswoord);
  }

  public function resetPaswoord($email) {
    $cursistDAO = new CursistDAO();
    $cursist = $cursistDAO->zoekCursistOpEmail($email);
    if ($cursist->getId() == null)
      throw new EmailAdresException("Onbestaand emailadres opgegeven");
    $paswoord = Paswoord::maak();
    $crypto = new BCrypt();
    $hash = $crypto->password_hash($paswoord, PASSWORD_DEFAULT);
    $cursistDAO->updatePaswoord($email, $hash);
    $this->verzendMail($email, $cursist->getVnaam(), $paswoord);
  }
  
}
