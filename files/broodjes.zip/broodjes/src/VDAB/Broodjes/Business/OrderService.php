<?php

namespace VDAB\Broodjes\Business;

use VDAB\Broodjes\Data\OrderDAO;
use VDAB\Broodjes\Exceptions\BestellingException;
use VDAB\Broodjes\Entities\Bestelling;
use stdClass;

class OrderService {

  public function broodjeBestaat($id) {
    $orderDAO = new OrderDAO();
    $broodje = $orderDAO->zoekBroodjeMetId($id);
    return $broodje->getId() != null;
  }

  /* geef broodjes en beleglijst */

  public function geefItems() {
    $orderDAO = new OrderDAO();
    $items = new stdClass();
    $items->broodjes = $orderDAO->geefBroodjes();
    $items->beleg = $orderDAO->geefBeleg();
    return $items;
  }

  public function checkTijdstip() {
    $tijdStr = date("H:i", time());
    if ($tijdStr < '07:00' || $tijdStr >= '10:00') {
      throw new BestellingException("Bestellen is niet meer mogelijk", 2);
    }
  }

  public function checkBestellingEnGeefItems($cursist_id) {
    if ($this->heeftCursistAlBesteld($cursist_id)) {
      throw new BestellingException("Er is vandaag al een bestelling gemaakt.", 1);
    }
    $this->checkTijdstip();
    return $this->geefItems();
  }

  public function belegBestaat($id) {
    $orderDAO = new OrderDAO();
    $beleg = $orderDAO->zoekBelegMetId($id);
    return $beleg->getId() != null;
  }

  public function geefBeleg($id) {
    $orderDAO = new OrderDAO();
    $beleg = $orderDAO->zoekBelegMetId($id);
    return $beleg;
  }

  public function voegBroodjeToe($id) {
    $orderDAO = new OrderDAO();
    $broodje = $orderDAO->zoekBroodjeMetId($id);
    if ($broodje->getId() != null)
      return $broodje;
  }

  public function voegBelegToe($broodje, $beleg_id) {
    $beleg = $this->geefBeleg($beleg_id);
    if ($beleg->getId() != null) {
      $broodje->voegBelegToe($beleg);
    }
  }

  public function verwijderBeleg($broodje, $beleg_id) {
    $broodje->verwijderBeleg($beleg_id);
  }

  /* bewaar order */

  public function heeftCursistAlBesteld($cursist_id) {
    $orderDAO = new OrderDAO();
    return $orderDAO->zoekOrderIdVanVandaag($cursist_id) != null;
  }

  public function bewaarOrder($cursist, $broodjes) {
    $cursist_id = $cursist->getId();
    $orderDAO = new OrderDAO();
    $order_id = $orderDAO->zoekOrderIdVanVandaag($cursist_id);
    if (!isset($order_id)) {
      $this->voegOrderToe($cursist_id);
      $order_id = $orderDAO->zoekOrderIdVanVandaag($cursist_id);
      $this->voegOrderLijnenToe($order_id, $broodjes);
    }
  }

  public function voegOrderToe($cursist_id) {
    $orderDAO = new OrderDAO();
    $datum = date('Y-m-d');
    $orderDAO->voegOrderToe($datum, $cursist_id);
  }

  public function voegOrderLijnenToe($order_id, $broodjes) {
    $order_nr = 0;
    foreach ($broodjes as $broodje) {
      $order_nr++;
      $broodje_id = $broodje->getId();
      $beleg_rij = $broodje->getBeleg();
      if (count($beleg_rij) > 0) {
        $this->voegOrderBroodjeMetBelegToe($order_id, $order_nr, $broodje_id, $beleg_rij);
      } else {
        $this->voegOrderBroodjeToe($order_id, $order_nr, $broodje_id);
      }
    }
  }

  public function voegOrderBroodjeMetBelegToe($order_id, $order_nr, $broodje_id, $beleg_rij) {
    $orderDAO = new OrderDAO();
    foreach ($beleg_rij as $beleg) {
      $beleg_id = $beleg->getId();
      $orderDAO->voegOrderLijnToe($order_id, $order_nr, $broodje_id, $beleg_id);
    }
  }

  public function voegOrderBroodjeToe($order_id, $order_nr, $broodje_id) {
    $orderDAO = new OrderDAO();
    $orderDAO->voegOrderLijnToe($order_id, $order_nr, $broodje_id, null);
  }

  public function geefOrderVanCursist($cursist_id) {
    if (!$this->heeftCursistAlBesteld($cursist_id))
      throw new BestellingException();
    $orderDAO = new OrderDAO();
    $order_rij = $orderDAO->haalOrderOp($cursist_id);
    $bestelling = new Bestelling($order_rij);
    return $bestelling->getBroodjes();
  }

}
