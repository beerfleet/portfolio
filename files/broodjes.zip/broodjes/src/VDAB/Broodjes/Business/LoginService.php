<?php

namespace VDAB\Broodjes\Business;

use VDAB\Broodjes\Lib\BCrypt\BCrypt;
use VDAB\Broodjes\Data\CursistDAO;

class LoginService {

  public function zoekGebruiker($email) {
    $cursistDAO = new CursistDAO();
    return $cursistDAO->zoekCursistOpEmail($email);
  }
  
  public function verifieerGebruiker($email, $paswoord) {    
    $cursist = $this->zoekGebruiker($email);
    $crypto = new BCrypt();
    return $crypto->password_verify($paswoord, $cursist->getPaswoord()) ? $cursist : null;
  }

}
