<?php

namespace VDAB\Broodjes\Entities;

use stdClass;

class Bestelling {

  private $broodjes = array();

  public function __construct($order_rij) {
    foreach ($order_rij as $order) {
      $this->voegBroodjeToe($order);
      $this->voegBelegToe($order);
    }
  }

  private function voegBroodjeToe($order) {
    if (!isset($this->broodjes[$order["order_nr"]])) {
      $id = $order["broodje_id"];
      $naam = $order["broodje"];
      $prijs = $order["prijs_broodje"];

      $dtoBroodje = new stdClass();
      $dtoBroodje->id = $id;
      $dtoBroodje->naam = $naam;
      $dtoBroodje->prijs = $prijs;
      $dtoBroodje->beleg = array();
      
      $this->broodjes[$order["order_nr"]] = $dtoBroodje;
    }
  }

  private function voegBelegToe($order) {
    $broodje = $this->broodjes[$order["order_nr"]];
    $id = $order["beleg_id"];
    $naam = $order["beleg"];
    $prijs = $order["prijs_beleg"];
    if (isset($order["beleg_id"])) {
      $dtoBeleg = new stdClass();
      $dtoBeleg->id = $id;
      $dtoBeleg->naam = $naam;
      $dtoBeleg->prijs = $prijs;
      $broodje->beleg[] = $dtoBeleg;
    }
  }

  public function getBroodjes() {
    return $this->broodjes;
  }

}
