<?php

namespace VDAB\Broodjes\Entities;

class Paswoord {

  private function __construct() {
    
  }

  public static function maak() {
    $start = 33; // ASCII uitroepteken, laagste teken
    $einde = 125; // ASCII sluit accolade, hoogste teken
    $paswoord = "";
    for ($i = 0; $i < 4; $i++) {
      $getalwaarde = rand($start, $einde);
      $paswoord .= chr($getalwaarde);
    }
    
    return $paswoord;
  }

}
