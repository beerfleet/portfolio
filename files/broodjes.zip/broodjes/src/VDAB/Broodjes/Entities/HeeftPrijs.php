<?php

namespace VDAB\Broodjes\Entities;

interface HeeftPrijs {

  function getPrijs();
}
