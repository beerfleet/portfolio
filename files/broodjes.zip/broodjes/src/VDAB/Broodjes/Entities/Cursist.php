<?php

namespace VDAB\Broodjes\Entities;

class Cursist {

  private static $idMap = array();
  private $id;
  private $vnaam;
  private $anaam;
  private $email;
  private $paswoord;

  function __construct($id, $vnaam, $anaam, $email, $paswoord) {
    $this->id = $id;
    $this->vnaam = $vnaam;
    $this->anaam = $anaam;
    $this->email = $email;
    $this->paswoord = $paswoord;
  }

  public static function create($id, $vnaam, $anaam, $email, $paswoord) {
    if (!isset(self::$idMap[$id])) {
      self::$idMap[$id] = new Cursist($id, $vnaam, $anaam, $email, $paswoord);
    }
    return self::$idMap[$id];
  }

  public static function getIdMap() {
    return self::$idMap;
  }

  public function getId() {
    return $this->id;
  }

  public function getVnaam() {
    return $this->vnaam;
  }

  public function getAnaam() {
    return $this->anaam;
  }

  public function getEmail() {
    return $this->email;
  }

  public function getPaswoord() {
    return $this->paswoord;
  }

  public static function setIdMap($idMap) {
    self::$idMap = $idMap;
  }

  public function setId($id) {
    $this->id = $id;
  }

  public function setVnaam($vnaam) {
    $this->vnaam = $vnaam;
  }

  public function setAnaam($anaam) {
    $this->anaam = $anaam;
  }

  public function setEmail($email) {
    $this->email = $email;
  }

  public function setPaswoord($paswoord) {
    $this->paswoord = $paswoord;
  }

}
