<?php

namespace VDAB\Broodjes\Entities;

class Broodje implements HeeftPrijs {

  private static $idMap = array();
  private $id;
  private $naam;
  private $prijs;
  private $beleg = array();

  private function __construct($id, $naam, $prijs) {
    $this->id = $id;
    $this->naam = $naam;
    $this->prijs = $prijs;
  }

  public static function create($id, $naam, $prijs) {
    if (!isset(self::$idMap[$id])) {
      self::$idMap[$id] = new Broodje($id, $naam, $prijs);
    }
    return self::$idMap[$id];
  }
 
  public function voegBelegToe($beleg) {
    if (!isset($this->beleg[$beleg->getId()])) {
      $this->beleg[$beleg->getId()] = $beleg;
    }
  }
  
  public function verwijderBeleg($id) {
    if (isset($this->beleg[$id])) {
      unset($this->beleg[$id]);
    }
  }

  public function getId() {
    return $this->id;
  }

  public function getNaam() {
    return $this->naam;
  }

  public function getPrijs() {
    return $this->prijs;
  }

  public function setId($id) {
    $this->id = $id;
  }

  public function setNaam($naam) {
    $this->naam = $naam;
  }

  public function setPrijs($prijs) {
    $this->prijs = $prijs;
  }

  public function getBeleg() {
    return $this->beleg;
  }

  public function setBeleg($beleg) {
    $this->beleg = $beleg;
  }

}
