<?php

namespace VDAB\Broodjes\Exceptions;

use Exception;

/**
 * Andere Problemen gerelateerd aan de data
 * 
 * @author JanVB
 */
class DataLaagException extends Exception {
  
}
