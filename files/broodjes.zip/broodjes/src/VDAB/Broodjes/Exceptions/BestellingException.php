<?php

namespace VDAB\Broodjes\Exceptions;

use Exception;

class BestellingException extends Exception {
  
}
