<?php

namespace VDAB\Broodjes\Exceptions;

use Exception;

/**
 * Problemen gerelateerd aan de toegang tot gegevensbron
 * 
 * @author JanVB
 */
class DataSourceException extends Exception {}
