<?php

namespace VDAB\Broodjes\Exceptions;

use Exception;

/**
 * Wordt getriggerd wanneer een bestaand emailadres wordt 
 * gebruikt om te registreren, of wanneer een onbestaand emailadres wordt
 * gebruikt om te updaten
 * 
 * @author JanVB
 */
class EmailAdresException extends Exception {
  //put your code here
}
