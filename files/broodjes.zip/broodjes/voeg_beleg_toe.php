<?php

use Doctrine\Common\ClassLoader;
use VDAB\Broodjes\Business\OrderService;

require_once './Doctrine/Common/ClassLoader.php';

$classloader = new ClassLoader("VDAB", "src");
$classloader->register();

try {
  if (!session_id())
    session_start();

  /* bestaat session ? */
  $broodjes_rij = array();
  if (isset($_SESSION["cursist"])) {
    if (isset($_GET["broodje_id"]) && isset($_GET["beleg_id"])) { /* bestaan get parameters ? */
      $broodje_index = (int) filter_input(INPUT_GET, "broodje_id");
      $beleg_id = (int) filter_input(INPUT_GET, "beleg_id");
      $broodjes_rij = $_SESSION["broodjes"];

      /* broodje MOET zich in de basket bevinden */
      if (isset($broodjes_rij[$broodje_index])) {
        $broodje = $broodjes_rij[$broodje_index];
        
        /* Voeg beleg toe aan session */
        $orderSrvc = new OrderService();
        $orderSrvc->voegBelegToe($broodje, $beleg_id);
      }

      /* terug naar belegscherm */
      header("Location: ./beleg_broodje.php?id=$broodje_index");
      exit(0);
    } else { /* fallback naar bestelling */
      header("Location: ./bestel.php");
      exit(0);
    }
  } else { /* session bestaat niet: aanmelden */
    header("Location: ./login.php");
    exit(0);
  }
} catch (Exception $ex) {
  include './fallback_login_inc.php';
}
