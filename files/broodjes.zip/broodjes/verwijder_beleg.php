<?php

use Doctrine\Common\ClassLoader;
use VDAB\Broodjes\Business\OrderService;

require_once './Doctrine/Common/ClassLoader.php';

$classloader = new ClassLoader("VDAB", "src");
$classloader->register();


try {  
  if (!session_id())
    session_start();
  /*Ingelogd ?*/
  if (isset($_SESSION["cursist"])) {
    if (isset($_GET["broodje_id"]) && isset($_GET["beleg_id"])) {
      $broodje_index = filter_input(INPUT_GET, "broodje_id");
      $beleg_index = filter_input(INPUT_GET, "beleg_id");
      $broodjes_rij = $_SESSION["broodjes"];

      /* broodje MOET zich in de basket bevinden */
      if (isset($broodjes_rij[$broodje_index])) {
        $broodje = $broodjes_rij[$broodje_index];
        
        /* Verwijder beleg */
        $orderSrvc = new OrderService();
        $orderSrvc->verwijderBeleg($broodje, $beleg_index);
      }
      
    }
    header("Location: ./beleg_broodje.php?id=$broodje_index");
    exit(0);    
  } else {
    header("Location: index.php");
    exit(0);
  }
} catch (Exception $ex) {  
  include './fallback_login_inc.php';
}