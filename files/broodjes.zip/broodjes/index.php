<?php

use Doctrine\Common\ClassLoader;

require_once './Doctrine/Common/ClassLoader.php';

$classloader = new ClassLoader("VDAB", "src");
$classloader->register();


try {
  if (!session_id()) session_start();
  if (isset($_SESSION["cursist"])) {
    $cursist = $_SESSION["cursist"];
    header ("Location: ./bestel.php");
    exit(0);
  } else {
    include './html/login.html';
  }
} catch (Exception $ex) {
  echo $ex->getMessage();
}