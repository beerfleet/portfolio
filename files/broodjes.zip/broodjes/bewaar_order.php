<?php

use Doctrine\Common\ClassLoader;
use VDAB\Broodjes\Business\OrderService;

require_once './Doctrine/Common/ClassLoader.php';


$classloader = new ClassLoader("VDAB", "src");
$classloader->register();


try {
  if (!session_id()) {
    session_start();
  }
  /* ingelogd ? */
  if (isset($_SESSION["cursist"])) {

    /* bestelopdracht gegeven ? */
    if (isset($_POST["bestel"])) {

      /* zijn er broodjes in de mand ? */
      if (isset($_SESSION["broodjes"]) && count($_SESSION["broodjes"]) > 0) {
        $cursist = $_SESSION["cursist"];
        $broodjes = $_SESSION["broodjes"];
        $orderSrvc = new OrderService();
        $orderSrvc->bewaarOrder($cursist, $broodjes);
      }
      header("Location: ./bestel.php");
      exit(0);
    } else {
      header("Location: ./bestel.php");
      exit(0);
    }
  } else {
    header("Location: ./login.php");
    exit(0);
  }
} catch (Exception $ex) {
  include './fallback_login_inc.php';
}