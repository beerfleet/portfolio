<?php

use Doctrine\Common\ClassLoader;
use VDAB\Broodjes\Business\LoginService;

require_once './Doctrine/Common/ClassLoader.php';

$classloader = new ClassLoader("VDAB", "src");
$classloader->register();


try {
  if (isset($_POST["login"])) {
    
    $loginSrvc = new LoginService();
    $email = $_POST["login"];
    $paswoord = $_POST["paswoord"];
    $cursist = $loginSrvc->verifieerGebruiker($email, $paswoord);
    if ($cursist) {
      session_start();
      $_SESSION["cursist"] = $cursist;      
      header("Location: bestel.php");
      exit(0);
    } else {
      $errBoodschap = "Kon gebruiker niet aanmelden";
      include './html/login.html';
    }
  } else if (isset($_GET["action"]) && $_GET["action"] == "afmelden") {
    session_start();
    session_destroy();
    unset($_SESSION["cursist"]);
    header("Location: index.php");
    exit(0);
  } else {
    header("Location: index.php");
    exit(0);
  }
} catch (Exception $ex) {
  $errBoodschap = $ex->getMessage();
  include './html/login.html';
}