<?php

if (isset($cursist)) {
  unset($cursist);
  session_destroy();
}
if (isset($ex)) {
  $errBoodschap = $ex->getMessage();  
}
include './html/login.html';
