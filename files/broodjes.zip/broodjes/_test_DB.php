<?php

use Doctrine\Common\ClassLoader;
use VDAB\Broodjes\Data\CursistDAO;
use VDAB\Broodjes\Data\OrderDAO;

require_once './Doctrine/Common/ClassLoader.php';

$classloader = new ClassLoader("VDAB", "src");
$classloader->register();

/* cursisten
  try {
  $cursistDAO = new CursistDAO();
  $cursistDAO->voegCursistToe("Jakke", "Van Biervliet", "janvb@pandora.be", "test");
  $cursistDAO->updatePaswoord("janvb@pandora.be", "appel");
  } catch (PDOException $ex) {
  echo $ex->getMessage();
  } */

/* broodjes
  try {
  $orderDAO = new OrderDAO();
  $broodjes = $orderDAO->zoekBroodjeMetId(49);
  echo "<pre>";
  print_r($broodjes);
  echo "</pre>";
  } catch (Exception $ex) {
  echo $ex->getMessage();
  } */

/* beleg
  try {
  $orderDAO = new OrderDAO();
  $beleg = $orderDAO->geefBeleg();
  echo "<pre>";
  print_r($beleg);
  echo "</pre>";
  } catch (Exception $ex) {
  echo $ex->getMessage();
  } */

/* try {
  $orderDAO = new OrderDAO();
  $cursist_id = 2;
  $datum = date('Y-m-d');
  //$datum = strtotime($datum);
  $orderDAO->voegOrderToe($datum, $cursist_id);

  $order_id = 20;
  $broodje_id = 7;

  $beleg_id = 31;
  $orderDAO->voegOrderLijnToe($order_id, $broodje_id, $beleg_id);

  $beleg_id = 25;
  $orderDAO->voegOrderLijnToe($order_id, $broodje_id, $beleg_id);

  $beleg_id = 18;
  $orderDAO->voegOrderLijnToe($order_id, $broodje_id, $beleg_id);


  } catch (Exception $ex) {
  echo $ex->getMessage();
  }

 */

try {
  $orderDAO = new OrderDAO();
  $order = $orderDAO->haalOrderOp(8);
  echo "<pre>";
  print_r($order);
  echo "</pre>";
} catch (Exception $ex) {
  $ex->getMessage();
}
