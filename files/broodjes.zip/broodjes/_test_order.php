<?php

use Doctrine\Common\ClassLoader;
use VDAB\Broodjes\Business\OrderService;

require_once './Doctrine/Common/ClassLoader.php';

$classloader = new ClassLoader("VDAB", "src");
$classloader->register();


try {
  $orderSrvc = new OrderService();
  $items = $orderSrvc->geefItems();
  echo "<pre>";
  //print_r($items);
  echo "</pre>";
} catch (Exception $ex) {
  echo $ex->getMessage();
}

try {
  $var = 17;
  $bestaat = $orderSrvc->broodjeBestaat($var);
  echo $bestaat ? "BROODJE $var BESTAAT" : "BROODJE $var BESTAAT NIET";
  echo "<br>";
} catch (Exception $ex) {
  echo $ex->getMessage();
}

try {
  
  $bestaat = $orderSrvc->belegBestaat($var);
  echo $bestaat ? "BELEG $var BESTAAT" : "BELEG $var BESTAAT NIET";
  echo "<br>";
} catch (Exception $ex) {
  echo $ex->getMessage();
}

try {
  echo $orderSrvc->heeftCursistAlBesteld(2) ? "Heeft besteld" : "Heeft niet besteld";
  echo "<br>";
} catch (Exception $ex) {
  echo $ex->getMessage();
}