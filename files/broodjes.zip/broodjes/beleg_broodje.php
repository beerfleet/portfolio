<?php

use Doctrine\Common\ClassLoader;
use VDAB\Broodjes\Business\OrderService;
use VDAB\Broodjes\Exceptions\BestellingException;

require_once './Doctrine/Common/ClassLoader.php';

$classloader = new ClassLoader("VDAB", "src");
$classloader->register();

try {
  if (!session_id())
    session_start();
  if (isset($_SESSION["cursist"])) {
    $cursist = $_SESSION["cursist"];
    $orderSrvc = new OrderService();
    $items = $orderSrvc->geefItems();

    /*zijn er broodjes in de session ? */
    if (isset($_SESSION["broodjes"])) {
      $displayMand["broodjes"] = $_SESSION["broodjes"];      
      if (isset($_GET["id"])) {
        $broodje_index = filter_input(INPUT_GET, "id");
        /* is de id van get eentje die in de bestelmand zit ? */
        if (isset($displayMand["broodjes"][$broodje_index])) {
          include './html/beleg_broodje.html';
        } else {
          header("Location: ./bestel.php");
          exit(0);
        }
      } else {
        header("Location: ./bestel.php");
        exit(0);
      }
    } else {
      header("Location: ./bestel.php");
      exit(0);
    }
  } else {
    header("Location: ./login.php");
    exit(0);
  }
} catch (Exception $ex) {
  include './fallback_login_inc.php';
}