<?php

use Doctrine\Common\ClassLoader;
use JVB\Bakkerij\Entities\Output;
use JVB\Bakkerij\Business\BestelService;
use JVB\Bakkerij\Exceptions\BestellingException;

require_once './Doctrine/Common/ClassLoader.php';

$classloader = new ClassLoader("JVB", "src");
$classloader->register();

$output = new Output();

try {
  //$bestelSrvc = new BestelService();
  $bestelSrvc = new BestelService();
  $datum = $bestelSrvc->mogelijkeBestelDatums();
  
  
  echo '<pre>';
  print_r($datum);
  echo '</pre>';
  
} catch (BestellingException $e) {
  $output->render('probleem.html.twig', array('probleem' => $e->getMessage()));
} catch (Exception $e) {
  $output->render('probleem.html.twig', array('probleem' => $e->getMessage()));
}