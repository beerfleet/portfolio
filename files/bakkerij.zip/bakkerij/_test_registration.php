<?php

use Doctrine\Common\ClassLoader;
use JVB\Bakkerij\Entities\Output;
use JVB\Bakkerij\Business\AdminService;

require_once './Doctrine/Common/ClassLoader.php';

$classloader = new ClassLoader("JVB", "src");
$classloader->register();

$output = new Output();

try {  
  $registratieSrvc = new AdminService();
  
  $registratieSrvc->registreerAdmin('Jan', 'Van Biervliet', 'janvb@pandora.be', 'Appel.Sap');  
  
} catch (Exception $ex) {
  echo $ex->getMessage();
}
