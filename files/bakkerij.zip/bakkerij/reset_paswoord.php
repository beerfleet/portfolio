<?php

use Doctrine\Common\ClassLoader;
use JVB\Bakkerij\Entities\Output;
use JVB\Bakkerij\Business\RegistratieService;
use JVB\Bakkerij\Exceptions\EmailadresException;

require_once './Doctrine/Common/ClassLoader.php';

$classloader = new ClassLoader("JVB", "src");
$classloader->register();

$output = new Output();

try {
  $vars = array();
  
  if (isset($_POST['email'])) {
    $email = $_POST['email'];
    $registratieSrvc = new RegistratieService();
    $registratieSrvc->resetPaswoord($email);
    $vars['msg'] = 'Uw wachtwoord werd gereset. Binnen enkele ogenblikken ontvangt u een e-mailtje '
            . 'met uw nieuwe gegevens.';
  }
  
  $output->render('reset_paswoord.html.twig', $vars);
} catch (EmailadresException $e) {
  $vars['err'] = $e->getMessage();
  $output->render('reset_paswoord.html.twig', $vars);
} catch (Exception $e) {
  $output->render('probleem.html.twig', array('probleem' => $e->getMessage()));
}
