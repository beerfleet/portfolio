<?php

use Doctrine\Common\ClassLoader;
use JVB\Bakkerij\Entities\Output;
use JVB\Bakkerij\Business\AdminService;

require_once './Doctrine/Common/ClassLoader.php';

$classloader = new ClassLoader("JVB", "src");
$classloader->register();

$output = new Output();

try {
  if (isset($_POST["login"])) {
    $loginSrvc = new AdminService();
    $email = filter_input(INPUT_POST, 'login', FILTER_VALIDATE_EMAIL);
    $paswoord = $_POST["paswoord"];
    $admin = $loginSrvc->verifieerAdmin($email, $paswoord);
    if ($admin) {
      $_SESSION["admin"] = $admin;      
      setcookie('login_admin', $admin->getEmail(), time() + 60 * 60 * 24 * 30 * 12);
      header('Location: admin.php');
      exit(0);
    } else {
      $_SESSION["msg"] = 'loginfout';
      header('Location: admin.php');
      exit(0);
    }
  }
  header('Location: admin.php');
  exit(0);
} catch (Exception $e) {
  $output->render('probleem.html.twig', array('probleem' => $e->getMessage()));
}