<?php

use Doctrine\Common\ClassLoader;
use JVB\Bakkerij\Entities\Output;
use JVB\Bakkerij\Entities\Paswoord;

require_once './Doctrine/Common/ClassLoader.php';

$classloader = new ClassLoader("JVB", "src");
$classloader->register();


try {
    echo '<pre>';
    for ($i=0; $i<100; $i++) {
      echo Paswoord::maak();      
      echo '<br>';
    }
    echo '<pre>';
  
} catch (Exception $ex) {
  echo $ex->getMessage();
}