<?php

use Doctrine\Common\ClassLoader;
use JVB\Bakkerij\Entities\Output;
use JVB\Bakkerij\Business\BestelService;
use JVB\Bakkerij\Exceptions\BestellingException;

require_once './Doctrine/Common/ClassLoader.php';

$classloader = new ClassLoader("JVB", "src");
$classloader->register();

$output = new Output();

try {
  if (!isset($_SESSION["aangemeld"])) {
    header('Location: index.php');
    exit(0);
  }
  if (isset($_SESSION['winkelmand'])) {
    $winkelmand = $_SESSION['winkelmand'];
  } else {
    $_SESSION["winkelmand"] = array();
    $winkelmand = array();
  }

  $klant = unserialize($_SESSION["aangemeld"]);  
  
  $bestelSrvc = new BestelService();
  $producten = $bestelSrvc->geefProducten($klant->getId());

  $vars = array('producten' => $producten, 'winkelmand' => $winkelmand, 'klant' => $klant);
  $output->render('product_overzicht.html.twig', $vars);

  $klant = unserialize($_SESSION['aangemeld']);
  $geblokkeerd = $klant->getGeblokkeerd();
} catch (BestellingException $e) {
  $_SESSION['boodschap'] = 'U heeft al de maximale aantal bestellingen gemaakt.'
          . ' Indien gewenst kan u 1 of meerdere bestelligen annuleren.';
  header('Location: toon_alle_bestellingen.php');
  exit(0);
} catch (Exception $e) {
  $output->render('probleem.html.twig', array('probleem' => $e->getMessage()));
}
