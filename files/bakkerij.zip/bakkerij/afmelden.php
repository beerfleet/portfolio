<?php

use Doctrine\Common\ClassLoader;
use JVB\Bakkerij\Entities\Output;

require_once './Doctrine/Common/ClassLoader.php';

$classloader = new ClassLoader("JVB", "src");
$classloader->register();

$output = new Output();

try {
  if (isset($_SESSION['aangemeld'])) {
    unset($_SESSION['aangemeld']);
    session_destroy();
  }
  header('Location: index.php');
  exit(0);
} catch (Exception $e) {
  $output->render('probleem.php', array('probleem' => $e->getMessage()));
}
