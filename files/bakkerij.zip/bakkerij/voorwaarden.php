<?php

use Doctrine\Common\ClassLoader;
use JVB\Bakkerij\Entities\Output;

require_once './Doctrine/Common/ClassLoader.php';

$classloader = new ClassLoader("JVB", "src");
$classloader->register();

$output = new Output();

try {
  $vars = array();
  
  //email 
  if (isset($_COOKIE['login']))
    $vars['login'] = $_COOKIE['login'];
  
  $output->render('voorwaarden.html.twig', $vars);
} catch (Exception $e) {
  $output->render('probleem.html.twig', array('probleem' => $e->getMessage()));
}