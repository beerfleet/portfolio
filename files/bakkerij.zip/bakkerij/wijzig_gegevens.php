<?php

use Doctrine\Common\ClassLoader;
use JVB\Bakkerij\Entities\Output;
use JVB\Bakkerij\Business\RegistratieService;
use JVB\Bakkerij\Entities\Postcode;

require_once './Doctrine/Common/ClassLoader.php';

$classloader = new ClassLoader("JVB", "src");
$classloader->register();

$output = new Output();

try {

  if (!isset($_SESSION["aangemeld"])) {
    header('Location: index.php');
    exit(0);
  }

  $klant = unserialize($_SESSION["aangemeld"]);

  if (isset($_POST['update'])) {
    $updateSrvc = new RegistratieService();
    $klant->setVoornaam(filter_input(INPUT_POST, 'voornaam'));
    $klant->setAchternaam(filter_input(INPUT_POST, 'achternaam'));
    $klant->setStraat(filter_input(INPUT_POST, 'straat'));
    $klant->setHuisnummer(filter_input(INPUT_POST, 'huisnummer'));
    $pc_id = filter_input(INPUT_POST, 'postcode');
    $postcode = new Postcode($pc_id);
    $klant->setPostcode($postcode);
    
    $paswoord = filter_input(INPUT_POST, 'paswoord');
    $trim_paswoord = trim($paswoord);
    $wijzig_paswoord = !empty($trim_paswoord);
                    
    $updateSrvc->updateKlant($klant, $wijzig_paswoord, $paswoord);

    // reflecteer gemaakte update in session
    $_SESSION["boodschap"] = 'De wijzigingen zijn bewaard';
    $_SESSION['aangemeld'] = serialize($klant);
    header('Location: beheer_account.php');
    exit(0);
  }

  $output->render('beheer_account.html.twig', $vars);
} catch (Exception $e) {
  $output->render('probleem.html.twig', array('probleem' => $e->getMessage()));
}