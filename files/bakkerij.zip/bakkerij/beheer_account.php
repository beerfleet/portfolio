<?php

use Doctrine\Common\ClassLoader;
use JVB\Bakkerij\Entities\Output;
use JVB\Bakkerij\Business\RegistratieService;

require_once './Doctrine/Common/ClassLoader.php';

$classloader = new ClassLoader("JVB", "src");
$classloader->register();

$output = new Output();

try {
  $vars = array();

  if (!isset($_SESSION["aangemeld"])) {
    header('Location: index.php');
    exit(0);
  }

  $klant = unserialize($_SESSION["aangemeld"]);
  $email = $klant->getEmail();

  $klantSrvc = new RegistratieService();
  $gegevens = $klantSrvc->geefKlantEnPostcodes($email);
  $klant = $gegevens['klant'];
  $postcodes = $gegevens['postcodes'];

  /* error data */
  if (isset($_SESSION['boodschap'])) {
    $vars['boodschap'] = $_SESSION['boodschap'];
    unset($_SESSION['boodschap']);
  }

  /* logon data */
  $vars['klant'] = unserialize($_SESSION['aangemeld']);
  $vars['postcodes'] = $postcodes;

  /* form data */
  $vars['voornaam'] = $klant->getVoornaam();
  $vars['achternaam'] = $klant->getAchternaam();
  $vars['straat'] = $klant->getStraat();
  $vars['huisnummer'] = $klant->getHuisnummer();
  $vars['postcode_id'] = $klant->getPostcode()->getId();
  $vars['achternaam'] = $klant->getAchternaam();
  $vars['email'] = $klant->getEmail();
  $output->render('beheer_account.html.twig', $vars);
} catch (Exception $e) {
  $output->render('probleem.html.twig', array('probleem' => $e->getMessage()));
}