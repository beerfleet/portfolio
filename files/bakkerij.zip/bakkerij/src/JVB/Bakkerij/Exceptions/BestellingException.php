<?php

namespace JVB\Bakkerij\Exceptions;

class BestellingException extends \Exception {
  
}
