<?php

namespace JVB\Bakkerij\Exceptions;

use Exception;

class DataSourceException extends Exception {
 
}
