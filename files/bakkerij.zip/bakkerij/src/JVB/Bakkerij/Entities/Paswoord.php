<?php

namespace JVB\Bakkerij\Entities;

class Paswoord {

  private function __construct() {
    
  }

  public static function maak() {
    $start = 33; // ASCII uitroepteken, laagste teken
    $einde = 125; // ASCII sluit accolade, hoogste teken
    $paswoord = "";
    for ($i = 0; $i < 6; $i++) {
      do {
        $getalwaarde = rand($start, $einde);
      } while ($getalwaarde == ord('*'));
      $paswoord .= chr($getalwaarde);
    }

    return $paswoord;
  }

}
