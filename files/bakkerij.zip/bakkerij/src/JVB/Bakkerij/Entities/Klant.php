<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace JVB\Bakkerij\Entities;

/**
 * Description of Klant
 *
 * @author Kukulkan
 */
class Klant {

  private $id;
  private $voornaam;
  private $achternaam;
  private $straat;
  private $huisnummer;
  private $postcode;
  private $email;
  private $paswoord;
  private $geblokkeerd = null;

  function __construct($id = null, $voornaam = null, $achternaam = null, $straat = null, 
          $huisnummer = null, Postcode $postcode = null, $email = null, $paswoord = null, $geblokkeerd = null) {
    $this->id = $id;
    $this->voornaam = $voornaam;
    $this->achternaam = $achternaam;
    $this->straat = $straat;
    $this->huisnummer = $huisnummer;
    $this->postcode = $postcode;
    $this->email = $email;
    $this->paswoord = $paswoord;
    $this->geblokkeerd = $geblokkeerd;
  }

  public function getId() {
    return $this->id;
  }

  public function getVoornaam() {
    return $this->voornaam;
  }

  public function getAchternaam() {
    return $this->achternaam;
  }

  public function getStraat() {
    return $this->straat;
  }

  public function getHuisnummer() {
    return $this->huisnummer;
  }

  public function getPostcode() {
    return $this->postcode;
  }

  public function getEmail() {
    return $this->email;
  }

  public function getPaswoord() {
    return $this->paswoord;
  }
  
  public function getGeblokkeerd() {
    return $this->geblokkeerd;
  }

  public function setId($id) {
    $this->id = $id;
  }

  public function setVoornaam($voornaam) {
    $this->voornaam = $voornaam;
  }

  public function setAchternaam($achternaam) {
    $this->achternaam = $achternaam;
  }

  public function setStraat($straat) {
    $this->straat = $straat;
  }

  public function setHuisnummer($huisnummer) {
    $this->huisnummer = $huisnummer;
  }

  public function setPostcode($postcode) {
    $this->postcode = $postcode;
  }

  public function setEmail($email) {
    $this->email = $email;
  }

  public function setPaswoord($paswoord) {
    $this->paswoord = $paswoord;
  }
  
  public function setGeblokkeerd($geblokkeerd) {
    $this->geblokkeerd = $geblokkeerd;
  }

}
