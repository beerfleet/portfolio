<?php

namespace JVB\Bakkerij\Entities;

class Admin {

  private $id;
  private $anaam;
  private $vnaam;
  private $email;
  private $paswoord;

  function __construct($id, $anaam, $vnaam, $email, $paswoord) {
    $this->id = $id;
    $this->anaam = $anaam;
    $this->vnaam = $vnaam;
    $this->email = $email;
    $this->paswoord = $paswoord;
  }

  public function getId() {
    return $this->id;
  }

  public function getAnaam() {
    return $this->anaam;
  }

  public function getVnaam() {
    return $this->vnaam;
  }

  public function getPaswoord() {
    return $this->paswoord;
  }

  public function setId($id) {
    $this->id = $id;
  }

  public function setAnaam($anaam) {
    $this->anaam = $anaam;
  }

  public function setVnaam($vnaam) {
    $this->vnaam = $vnaam;
  }

  public function setPaswoord($paswoord) {
    $this->paswoord = $paswoord;
  }
  
  public function getEmail() {
    return $this->email;
  }

  public function setEmail($email) {
    $this->email = $email;
  }

}
