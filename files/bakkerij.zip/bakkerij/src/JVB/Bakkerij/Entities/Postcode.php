<?php

namespace JVB\Bakkerij\Entities;

class Postcode {

  private static $idMap = array();
  
  private $id;
  private $postcode;
  private $gemeente;

  function __construct($id, $postcode = null, $gemeente = null) {
    $this->id = $id;
    $this->postcode = $postcode;
    $this->gemeente = $gemeente;
  }
  
  public static function maakUniek($id, $postcode, $gemeente) {
    if (!isset(self::$idMap[$id])) {
      self::$idMap[$id] = new Postcode($id, $postcode, $gemeente);
    }
    return self::$idMap[$id];
  }

  public function getId() {
    return $this->id;
  }

  public function getPostcode() {
    return $this->postcode;
  }

  public function getGemeente() {
    return $this->gemeente;
  }

  public function setId($id) {
    $this->id = $id;
  }

  public function setPostcode($postcode) {
    $this->postcode = $postcode;
  }

  public function setGemeente($gemeente) {
    $this->gemeente = $gemeente;
  }

}
