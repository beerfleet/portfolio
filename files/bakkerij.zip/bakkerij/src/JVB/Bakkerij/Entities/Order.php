<?php

namespace JVB\Bakkerij\Entities;

use JVB\Bakkerij\Entities\Klant;

class Order {

  private static $idMap = array();
  
  private $id;
  private $datum_besteld;
  private $datum_ophalen;
  private $klant;
  private $orderlijnen = array();

  function __construct($id, $datum_besteld, $datum_ophalen, Klant $klant = null, array $orderlijnen = null) {
    $this->id = $id;
    $this->datum_besteld = $datum_besteld;
    $this->datum_ophalen = $datum_ophalen;
    $this->klant = $klant;
    $this->orderlijnen = $orderlijnen;
  }
  
  public static function maakUniek($id, $datum_besteld, $datum_ophalen) {
    if (!isset(self::$idMap[$id])) {
      self::$idMap[$id] = new Order($id, $datum_besteld, $datum_ophalen);      
    }
    return self::$idMap[$id];
  }
  
  public function voegOrderLijnToe(Orderlijn $orderlijn) {
    $this->orderlijnen[$orderlijn->getId()] = $orderlijn;
  }

  public function getId() {
    return $this->id;
  }

  public function getDatum_besteld() {
    return $this->datum_besteld;
  }

  public function getDatum_ophalen() {
    return $this->datum_ophalen;
  }

  public function getKlant() {
    return $this->klant;
  }

  public function getOrderlijnen() {
    return $this->orderlijnen;
  }

  public function setId($id) {
    $this->id = $id;
  }

  public function setDatum_besteld($datum_besteld) {
    $this->datum_besteld = $datum_besteld;
  }

  public function setDatum_ophalen($datum_ophalen) {
    $this->datum_ophalen = $datum_ophalen;
  }

  public function setKlant($klant) {
    $this->klant = $klant;
  }

  public function setOrderlijnen($orderlijnen) {
    $this->orderlijnen = $orderlijnen;
  }

}
