<?php

namespace JVB\Bakkerij\Entities;

use JVB\Bakkerij\Entities;

class Orderlijn {

  private $id;  
  private $lijn_nr;
  private $product;
  private $aantal;

  function __construct($id, $lijn_nr, Product $product, $aantal) {
    $this->id = $id;    
    $this->lijn_nr = $lijn_nr;
    $this->product = $product;
    $this->aantal = $aantal;
  }

  public function getId() {
    return $this->id;
  }

  public function getOrder() {
    return $this->order;
  }

  public function getLijn_nr() {
    return $this->lijn_nr;
  }

  public function getProduct() {
    return $this->product;
  }

  public function getAantal() {
    return $this->aantal;
  }

  public function setId($id) {
    $this->id = $id;
  }

  public function setOrder($order) {
    $this->order = $order;
  }

  public function setLijn_nr($lijn_nr) {
    $this->lijn_nr = $lijn_nr;
  }

  public function setProduct($product) {
    $this->product = $product;
  }

  public function setAantal($aantal) {
    $this->aantal = $aantal;
  }

}
