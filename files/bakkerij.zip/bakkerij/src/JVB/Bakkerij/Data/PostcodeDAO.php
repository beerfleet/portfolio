<?php

namespace JVB\Bakkerij\Data;

use JVB\Bakkerij\Entities\DBHelper;
use JVB\Bakkerij\Entities\Postcode;
use PDOException;

class PostcodeDAO {

  public function haalPostcodesOp() {
    $postcodes = array();
    try {
      $dbh = DBHelper::connect();
      $sql = "SELECT id, postcode, gemeente FROM postcodes ORDER BY postcode";
      $sth = $dbh->prepare($sql);

      $sth->execute();
      $postcodes_rs = $sth->fetchAll();
      $dbh = null;
      foreach ($postcodes_rs as $pc) {
        $postcode = new Postcode($pc['id'], $pc['postcode'], $pc['gemeente']);
        $postcodes[$pc['id']] = $postcode;
      }
      return $postcodes;
    } catch (PDOException $e) {
      $code = $e->getCode();
      switch ($code) {
        case "2002": /* Geen DB connectie */
        case "1049": /* Onbekende Database */
        case "1045": /* Ongeldige credentials */
        case "1044": /* Access denied */
          throw new DataSourceException("Kan geen toegang tot de gegevens krijgen.");
        default:
          throw new DataLaagException($e->getMessage());
        //throw new DataLaagException("Er was een onvoorzien probleem met de toegang tot de gegevens");
      }
    }
  }

}
