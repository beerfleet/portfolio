<?php

namespace JVB\Bakkerij\Data;

use JVB\Bakkerij\Entities\DBHelper;
use JVB\Bakkerij\Entities\Admin;
use PDOException;
use JVB\Bakkerij\Exceptions\DataLaagException;
use JVB\Bakkerij\Exceptions\DataSourceException;

class AdminDAO {

  public function insertAdmin($anaam, $vnaam, $email, $paswoord) {
    try {
      $sql = "INSERT INTO admins (anaam, vnaam, email, paswoord) "
              . "VALUES (?, ?, ?, ?)";
      $dbh = DBHelper::connect();
      $sth = $dbh->prepare($sql);
      $sth->bindParam(1, $anaam);
      $sth->bindParam(2, $vnaam);
      $sth->bindParam(3, $email);
      $sth->bindParam(4, $paswoord);
      $sth->execute();
      $dbh = null;
    } catch (PDOException $e) {
      $code = $e->getCode();
      switch ($code) {
        case "2002": /* Geen DB connectie */
        case "1049": /* Onbekende Database */
        case "1045": /* Ongeldige credentials */
        case "1044": /* Access denied */
          throw new DataSourceException("Kan geen toegang tot de gegevens krijgen.");
        default:
          throw new DataLaagException($e->getMessage());
        //throw new DataLaagException("Er was een onvoorzien probleem met de toegang tot de gegevens");
      }
    }
  }

  public function geefAdmin($email) {
    try {
      $sql = "SELECT id, anaam, vnaam, email, paswoord "
              . "FROM admins "
              . "WHERE email = ?";
      $dbh = DBHelper::connect();
      $sth = $dbh->prepare($sql);
      $sth->bindParam(1, $email);
      $sth->execute();
      $dbh = null;
      $admin = $sth->fetch();
      return new Admin($admin['id'], $admin['anaam'], $admin['vnaam'], $admin['email'], $admin['paswoord']);
    } catch (PDOException $e) {
      $code = $e->getCode();
      switch ($code) {
        case "2002": /* Geen DB connectie */
        case "1049": /* Onbekende Database */
        case "1045": /* Ongeldige credentials */
        case "1044": /* Access denied */
          throw new DataSourceException("Kan geen toegang tot de gegevens krijgen.");
        default:
          throw new DataLaagException($e->getMessage());
        //throw new DataLaagException("Er was een onvoorzien probleem met de toegang tot de gegevens");
      }
    }
  }

}
