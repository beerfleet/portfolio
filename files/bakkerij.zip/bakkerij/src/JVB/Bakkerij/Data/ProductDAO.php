<?php

namespace JVB\Bakkerij\Data;

use JVB\Bakkerij\Entities\Product;
use JVB\Bakkerij\Exceptions\DataLaagException;
use JVB\Bakkerij\Exceptions\DataSourceException;
use JVB\Bakkerij\Entities\DBHelper;
use PDO;
use PDOException;

class ProductDAO {

  public function geefAlleProducten() {
    try {
      $producten = array();
      $sql = "SELECT id, naam, prijs FROM producten ORDER BY naam";
      $dbh = DBHelper::connect();
      $sth = $dbh->prepare($sql);
      $sth->execute();
      $product_rij = $sth->fetchAll();
      $dbh = null;
      foreach ($product_rij as $prod) {
        $producten[$prod['id']] = new Product($prod['id'], $prod['naam'], $prod['prijs']);
      }
      return $producten;
    } catch (PDOException $e) {
      $code = $e->getCode();
      switch ($code) {
        case "2002": /* Geen DB connectie */
        case "1049": /* Onbekende Database */
        case "1045": /* Ongeldige credentials */
        case "1044": /* Access denied */
          throw new DataSourceException("Kan geen toegang tot de gegevens krijgen.");
        default:
          throw new DataLaagException($e->getMessage());
        //throw new DataLaagException("Er was een onvoorzien probleem met de toegang tot de gegevens");
      }
    }
  }

  public function geefSelectieProducten(array $selectie) {
    try {
      $prod_obj = array();
      $dbh = DBHelper::connect();
      $ids = array_keys($selectie);
      foreach ($ids as &$val) {
        $val = $dbh->quote($val);
      }
      $in = implode(",", $ids);
      $sql = "SELECT id, naam, prijs FROM producten "
              . "WHERE id IN ($in)";
      $sth = $dbh->prepare($sql);
      $sth->execute();
      $prod_sel = $sth->fetchAll();
      $dbh = null;
      foreach ($prod_sel as $prod) {
        $prod_obj[$prod['id']] = new Product($prod['id'], $prod['naam'], $prod['prijs']);
      }
      return $prod_obj;
    } catch (PDOException $e) {
      $code = $e->getCode();
      switch ($code) {
        case "2002": /* Geen DB connectie */
        case "1049": /* Onbekende Database */
        case "1045": /* Ongeldige credentials */
        case "1044": /* Access denied */
          throw new DataSourceException("Kan geen toegang tot de gegevens krijgen.");
        default:
          throw new DataLaagException($e->getMessage());
        //throw new DataLaagException("Er was een onvoorzien probleem met de toegang tot de gegevens");
      }
    }
  }

}
