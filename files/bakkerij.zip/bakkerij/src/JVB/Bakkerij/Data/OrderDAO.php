<?php

namespace JVB\Bakkerij\Data;

use JVB\Bakkerij\Entities\DBHelper;
use JVB\Bakkerij\Entities\Order;
use JVB\Bakkerij\Entities\Orderlijn;
use JVB\Bakkerij\Entities\Product;
use JVB\Bakkerij\Entities\Klant;
use \PDO;
use \PDOException;
use JVB\Bakkerij\Exceptions\DataLaagException;
use JVB\Bakkerij\Exceptions\DataSourceException;

class OrderDAO {

  private function geefStartEnEindDatum($vandaagInbegrepen = false) {
    $datum_vandaag = strtotime(date('Y-m-d'));
    if ($vandaagInbegrepen) {
      $start_datum = $datum_vandaag + 60 * 60;
    } else {
      $start_datum = $datum_vandaag + 60 * 60 * 24;
    }
    $eind_datum = $datum_vandaag + 60 * 60 * 24 * 3;
    $str_start_datum = date('Y-m-d', $start_datum);
    $str_eind_datum = date('Y-m-d', $eind_datum);
    return array('start' => $str_start_datum, 'einde' => $str_eind_datum);
  }

  public function geefDatumsOphaling($klant_id) {
    try {
      $datums = array();

      $str_datums = $this->geefStartEnEindDatum();

      $sql = "SELECT datum_ophalen FROM orders WHERE datum_ophalen BETWEEN ? AND ? "
              . "AND klant_id = ?";
      $dbh = DBHelper::connect();
      $sth = $dbh->prepare($sql);

      $sth->bindParam(1, $str_datums['start']);
      $sth->bindParam(2, $str_datums['einde']);
      $sth->bindParam(3, $klant_id);
      $sth->execute();
      $datum_rs = $sth->fetchAll();
      $dbh = null;
      foreach ($datum_rs as $dat) {
        $datums[] = $dat['datum_ophalen'];
      }
      return $datums;
    } catch (PDOException $e) {
      $code = $e->getCode();
      switch ($code) {
        case "2002": /* Geen DB connectie */
        case "1049": /* Onbekende Database */
        case "1045": /* Ongeldige credentials */
        case "1044": /* Access denied */
          throw new DataSourceException("Kan geen toegang tot de gegevens krijgen.");
        default:
          throw new DataLaagException($e->getMessage());
//throw new DataLaagException("Er was een onvoorzien probleem met de toegang tot de gegevens");
      }
    }
  }

  public function voegOrderToe($datum_besteld, $datum_ophalen, $klant_id) {
    try {
      $sql = "INSERT INTO orders (datum_besteld, datum_ophalen, klant_id) VALUES (?, ?, ?)";
      $dbh = DBHelper::connect();
      $sth = $dbh->prepare($sql);
      $sth->bindParam(1, $datum_besteld);
      $sth->bindParam(2, $datum_ophalen);
      $sth->bindParam(3, $klant_id, PDO::PARAM_INT);
      $sth->execute();
      $dbh = null;
    } catch (PDOException $e) {
      $code = $e->getCode();
      switch ($code) {
        case "2002": /* Geen DB connectie */
        case "1049": /* Onbekende Database */
        case "1045": /* Ongeldige credentials */
        case "1044": /* Access denied */
          throw new DataSourceException("Kan geen toegang tot de gegevens krijgen.");
        default:
          throw new DataLaagException($e->getMessage());
//throw new DataLaagException("Er was een onvoorzien probleem met de toegang tot de gegevens");
      }
    }
  }

  public function voegOrderLijnToe($order_id, $lijn_nr, $product_id, $aantal) {
    try {
      $sql = "INSERT INTO orderlijnen (order_id, lijn_nr, product_id, aantal) VALUES "
              . "(?, ?, ?, ?)";
      $dbh = DBHelper::connect();
      $sth = $dbh->prepare($sql);
      $sth->bindParam(1, $order_id, PDO::PARAM_INT);
      $sth->bindParam(2, $lijn_nr, PDO::PARAM_INT);
      $sth->bindParam(3, $product_id, PDO::PARAM_INT);
      $sth->bindParam(4, $aantal, PDO::PARAM_INT);
      $sth->execute();
      $dbh = null;
    } catch (PDOException $e) {
      $code = $e->getCode();
      switch ($code) {
        case "2002": /* Geen DB connectie */
        case "1049": /* Onbekende Database */
        case "1045": /* Ongeldige credentials */
        case "1044": /* Access denied */
          throw new DataSourceException("Kan geen toegang tot de gegevens krijgen.");
        default:
          throw new DataLaagException($e->getMessage());
//throw new DataLaagException("Er was een onvoorzien probleem met de toegang tot de gegevens");
      }
    }
  }

  public function geefOrderVan($klant_id, $datum_ophalen) {
    try {
      $sql = "SELECT id, datum_besteld, datum_ophalen, klant_id "
              . "FROM orders "
              . "WHERE klant_id = ? "
              . "AND datum_ophalen = ?";
      $dbh = DBHelper::connect();
      $sth = $dbh->prepare($sql);
      $sth->bindParam(1, $klant_id);
      $sth->bindParam(2, $datum_ophalen);
      $sth->execute();
      $order_rs = $sth->fetch();
      $dbh = null;
      $order = new Order($order_rs['id'], $order_rs['datum_besteld'], $order_rs['datum_ophalen'], new Klant(), array());
      return $order;
    } catch (PDOException $e) {
      $code = $e->getCode();
      switch ($code) {
        case "2002": /* Geen DB connectie */
        case "1049": /* Onbekende Database */
        case "1045": /* Ongeldige credentials */
        case "1044": /* Access denied */
          throw new DataSourceException("Kan geen toegang tot de gegevens krijgen.");
        default:
          throw new DataLaagException($e->getMessage());
//throw new DataLaagException("Er was een onvoorzien probleem met de toegang tot de gegevens");
      }
    }
  }

  private function maakBestellingObjecten($bestellingen_rs) {
    $orders = array();
    foreach ($bestellingen_rs as $rij) {
      $orders[$rij['order_id']] = Order::maakUniek($rij['order_id'], $rij['datum_besteld'], $rij['datum_ophalen']);
      $product = Product::maakUniek($rij['product_id'], $rij['naam'], $rij['prijs']);
      $orderlijn = new Orderlijn($rij['orderlijn_id'], $rij['lijn_nr'], $product, $rij['aantal']);
      $orders[$rij['order_id']]->voegOrderLijnToe($orderlijn);
    }
    return $orders;
  }

  public function geefAlleBestellingen($klant_id) {
    try {
      $bestellingen = array();
      $str_datums = $this->geefStartEnEindDatum(true);
      $sql = "SELECT o.id as 'order_id', datum_besteld, datum_ophalen,"
              . "ol.id as 'orderlijn_id', lijn_nr, aantal, "
              . "p.id as 'product_id', naam, prijs "
              . "FROM orders o "
              . "JOIN orderlijnen ol ON (o.id = ol.order_id) "
              . "join producten p on (p.id = product_id) "
              . "WHERE datum_ophalen BETWEEN ? AND ? "
              . "AND klant_id = ?";
      $dbh = DBHelper::connect();
      $sth = $dbh->prepare($sql);
      $sth->bindParam(1, $str_datums['start']);
      $sth->bindParam(2, $str_datums['einde']);
      $sth->bindParam(3, $klant_id, PDO::PARAM_INT);
      $sth->execute();
      $dbh = null;
      $bestellingen = $this->maakBestellingObjecten($sth->fetchAll());
      return $bestellingen;
    } catch (PDOException $e) {
      $code = $e->getCode();
      switch ($code) {
        case "2002": /* Geen DB connectie */
        case "1049": /* Onbekende Database */
        case "1045": /* Ongeldige credentials */
        case "1044": /* Access denied */
          throw new DataSourceException("Kan geen toegang tot de gegevens krijgen.");
        default:
          throw new DataLaagException($e->getMessage());
//throw new DataLaagException("Er was een onvoorzien probleem met de toegang tot de gegevens");
      }
    }
  }

  public function deleteOrder($order_id) {
    try {
      $sql = "DELETE FROM orders WHERE id = ?";
      $dbh = DBHelper::connect();
      $sth = $dbh->prepare($sql);
      $sth->bindParam(1, $order_id, PDO::PARAM_INT);
      $sth->execute();
      $dbh = null;
    } catch (PDOException $e) {
      $code = $e->getCode();
      switch ($code) {
        case "2002": /* Geen DB connectie */
        case "1049": /* Onbekende Database */
        case "1045": /* Ongeldige credentials */
        case "1044": /* Access denied */
          throw new DataSourceException("Kan geen toegang tot de gegevens krijgen.");
        default:
          throw new DataLaagException($e->getMessage());
//throw new DataLaagException("Er was een onvoorzien probleem met de toegang tot de gegevens");
      }
    }
  }

}
