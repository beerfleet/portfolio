<?php

namespace JVB\Bakkerij\Data;

use JVB\Bakkerij\Entities\DBHelper;
use \PDO;
use \PDOException;
use JVB\Bakkerij\Exceptions\DataLaagException;
use JVB\Bakkerij\Exceptions\EmailadresException;
use JVB\Bakkerij\Exceptions\DataSourceException;
use JVB\Bakkerij\Entities\Klant;
use JVB\Bakkerij\Entities\Postcode;

class KlantDAO {

  public function insertKlant(Klant $klant) {
    try {
      $sql = "INSERT INTO klanten (vnaam, anaam, straat, huisnummer, postcode_id, email, paswoord) "
              . "VALUES (?, ?, ?, ?, ?, ?, ?)";
      $dbh = DBHelper::connect();

      $sth = $dbh->prepare($sql);
      $vnaam = $klant->getVoornaam();
      $anaam = $klant->getAchternaam();
      $straat = $klant->getStraat();
      $huisnummer = $klant->getHuisnummer();
      $postcode_id = $klant->getPostcode()->getId();
      $email = $klant->getEmail();
      $paswoord = $klant->getPaswoord();
      
      $sth->bindParam(1, $vnaam, PDO::PARAM_STR);
      $sth->bindParam(2, $anaam, PDO::PARAM_STR);
      $sth->bindParam(3, $straat, PDO::PARAM_STR);
      $sth->bindParam(4, $huisnummer, PDO::PARAM_STR);
      $sth->bindParam(5, $postcode_id, PDO::PARAM_INT);
      $sth->bindParam(6, $email, PDO::PARAM_STR);
      $sth->bindParam(7, $paswoord, PDO::PARAM_STR);
      $sth->execute();
      $dbh = null;
    } catch (PDOException $e) {
      $code = $e->getCode();
      switch ($code) {
        case "23000":
          throw new EmailadresException("E-mailadres bestaat al.");
        case "2002": /* Geen DB connectie */
        case "1049": /* Onbekende Database */
        case "1045": /* Ongeldige credentials */
        case "1044": /* Access denied */
          throw new DataSourceException("Kan geen toegang tot de gegevens krijgen.");
        default:
          throw new DataLaagException($e->getMessage());
        //throw new DataLaagException("Er was een onvoorzien probleem met de toegang tot de gegevens");
      }
    }
  }

  public function zoekKlantOpEmail($email) {
    try {
      $sql = "SELECT k.id as klant_id, vnaam, anaam, straat, huisnummer, postcode_id, postcode, gemeente, email, paswoord, geblokkeerd "
              . "FROM klanten k, postcodes p "
              . "WHERE email = ? "
              . "AND postcode_id = p.id";
      $dbh = DBHelper::connect();
      $sth = $dbh->prepare($sql);
      $sth->bindParam(1, $email, PDO::PARAM_STR);
      $sth->execute();
      $klant = $sth->fetch();
      $postcode = new Postcode($klant['postcode_id'], $klant['postcode'], $klant['gemeente']);
      $klant_obj = new Klant($klant['klant_id'], $klant['vnaam'], $klant['anaam'], $klant['straat'], $klant['huisnummer'], $postcode, $klant['email'], $klant['paswoord'], $klant['geblokkeerd']);
      $dbh = null;
      return $klant_obj;
    } catch (PDOException $e) {
      $code = $e->getCode();
      switch ($code) {
        case "2002": /* Geen DB connectie */
        case "1049": /* Onbekende Database */
        case "1045": /* Ongeldige credentials */
        case "1044": /* Access denied */
          throw new DataSourceException("Kan geen toegang tot de gegevens krijgen.");
        default:
          throw new DataLaagException($e->getMessage());
        //throw new DataLaagException("Er was een onvoorzien probleem met de toegang tot de gegevens");
      }
    }
  }

  public function geeefAllekKlanten() {
    try {
      $klanten = array();
      $sql = "SELECT k.id, vnaam, anaam, straat, huisnummer, postcode_id, email, paswoord, geblokkeerd, "
              . "postcode, gemeente "
              . "FROM klanten k "
              . "JOIN postcodes p ON (p.id = k.postcode_id)";
      $dbh = DBHelper::connect();
      $sth = $dbh->prepare($sql);
      $sth->execute();
      $klanten_rs = $sth->fetchAll();
      foreach ($klanten_rs as $klant) {
        $postcode = Postcode::maakUniek($klant['postcode_id'], $klant['postcode'], $klant['gemeente']);
        $klanten[$klant['id']] = new Klant($klant['id'], $klant['vnaam'], $klant['anaam'], $klant['straat'], $klant['huisnummer'], $postcode, $klant['email'], $klant['paswoord'], $klant['geblokkeerd']);
      }
      return $klanten;
    } catch (PDOException $e) {
      $code = $e->getCode();
      switch ($code) {
        case "2002": /* Geen DB connectie */
        case "1049": /* Onbekende Database */
        case "1045": /* Ongeldige credentials */
        case "1044": /* Access denied */
          throw new DataSourceException("Kan geen toegang tot de gegevens krijgen.");
        default:
          throw new DataLaagException($e->getMessage());
        //throw new DataLaagException("Er was een onvoorzien probleem met de toegang tot de gegevens");
      }
    }
  }

  public function deblokkeerKlant($klant_id) {
    try {
      $sql = "UPDATE klanten SET geblokkeerd = null "
              . "WHERE id = ?";
      $dbh = DBHelper::connect();
      $sth = $dbh->prepare($sql);
      $sth->bindParam(1, $klant_id, PDO::PARAM_INT);
      $sth->execute();
      $dbh = null;
    } catch (PDOException $e) {
      $code = $e->getCode();
      switch ($code) {
        case "2002": /* Geen DB connectie */
        case "1049": /* Onbekende Database */
        case "1045": /* Ongeldige credentials */
        case "1044": /* Access denied */
          throw new DataSourceException("Kan geen toegang tot de gegevens krijgen.");
        default:
          throw new DataLaagException($e->getMessage());
        //throw new DataLaagException("Er was een onvoorzien probleem met de toegang tot de gegevens");
      }
    }
  }

  public function blokkeerKlant($klant_id) {
    try {
      $sql = "UPDATE klanten SET geblokkeerd = 1 "
              . "WHERE id = ?";
      $dbh = DBHelper::connect();
      $sth = $dbh->prepare($sql);
      $sth->bindParam(1, $klant_id, PDO::PARAM_INT);
      $sth->execute();
      $dbh = null;
    } catch (PDOException $e) {
      $code = $e->getCode();
      switch ($code) {
        case "2002": /* Geen DB connectie */
        case "1049": /* Onbekende Database */
        case "1045": /* Ongeldige credentials */
        case "1044": /* Access denied */
          throw new DataSourceException("Kan geen toegang tot de gegevens krijgen.");
        default:
          throw new DataLaagException($e->getMessage());
        //throw new DataLaagException("Er was een onvoorzien probleem met de toegang tot de gegevens");
      }
    }
  }

  public function updatePaswoord($email, $hash) {
    try {
      $sql = "UPDATE klanten SET paswoord = ? "
              . "WHERE email = ?";
      $dbh = DBHelper::connect();
      $sth = $dbh->prepare($sql);
      $sth->bindParam(1, $hash);
      $sth->bindParam(2, $email);
      $sth->execute();
      $bdh = null;
    } catch (PDOException $e) {
      $code = $e->getCode();
      switch ($code) {
        case "2002": /* Geen DB connectie */
        case "1049": /* Onbekende Database */
        case "1045": /* Ongeldige credentials */
        case "1044": /* Access denied */
          throw new DataSourceException("Kan geen toegang tot de gegevens krijgen.");
        default:
          throw new DataLaagException($e->getMessage());
        //throw new DataLaagException("Er was een onvoorzien probleem met de toegang tot de gegevens");
      }
    }
  }
  
  public function updateKlant(Klant $klant) {
    try {
      $sql = "UPDATE klanten SET vnaam = ?, anaam = ?, straat = ?, huisnummer = ?, postcode_id = ?, paswoord = ? WHERE id = ?";
      $dbh = DBHelper::connect();

      $sth = $dbh->prepare($sql);      
      $vnaam = $klant->getVoornaam();
      $anaam = $klant->getAchternaam();
      $straat = $klant->getStraat();
      $huisnummer = $klant->getHuisnummer();
      $postcode_id = $klant->getPostcode()->getId();      
      $paswoord = $klant->getPaswoord();
      $id = $klant->getId();
      
      $sth->bindParam(1, $vnaam, PDO::PARAM_STR);
      $sth->bindParam(2, $anaam, PDO::PARAM_STR);
      $sth->bindParam(3, $straat, PDO::PARAM_STR);
      $sth->bindParam(4, $huisnummer, PDO::PARAM_STR);
      $sth->bindParam(5, $postcode_id, PDO::PARAM_INT);
      $sth->bindParam(6, $paswoord, PDO::PARAM_STR);
      $sth->bindParam(7, $id, PDO::PARAM_INT);
      
      $sth->execute();
      $dbh = null;
    } catch (PDOException $e) {
      $code = $e->getCode();
      switch ($code) {        
        case "2002": /* Geen DB connectie */
        case "1049": /* Onbekende Database */
        case "1045": /* Ongeldige credentials */
        case "1044": /* Access denied */
          throw new DataSourceException("Kan geen toegang tot de gegevens krijgen.");
        default:
          throw new DataLaagException($e->getMessage());
        //throw new DataLaagException("Er was een onvoorzien probleem met de toegang tot de gegevens");
      }
    }
  }

}
