<?php

namespace JVB\Bakkerij\Business;

use JVB\Bakkerij\Data\ProductDAO;
use JVB\Bakkerij\Data\OrderDAO;
use JVB\Bakkerij\Exceptions\BestellingException;
use stdClass;

class BestelService {

  public function geefProducten($klant_id) {
    $productDAO = new ProductDAO();
    $this->mogelijkeBestelDatums($klant_id);
    return $productDAO->geefAlleProducten();
  }

  public function geefBestelOverzicht(array $selectie, $klant_id) {
    $productDAO = new ProductDAO();
    $producten = $productDAO->geefSelectieProducten($selectie);
    $producten_rij = array();
    foreach ($producten as $product) {
      $prod_std = new stdClass();
      $prod_std->product = $product;
      $prod_std->aantal = $selectie[$product->getId()];
      $producten_rij['producten'][$product->getId()] = $prod_std;
    }
    $producten_rij['datums'] = $this->mogelijkeBestelDatums($klant_id);
    return $producten_rij;
  }

  public function mogelijkeBestelDatums($klant_id) {
    $orderDAO = new OrderDAO();
    $datums_besteld = $orderDAO->geefDatumsOphaling($klant_id);
    if (count($datums_besteld) == 3) {
      throw new BestellingException("Er zijn geen bestellingen meer mogelijk, tenzij "
      . "u een of meerdere bestellingen annuleert.");
    }

    $geldige_keuzes = array();
    for ($i = 1; $i <= 3; $i++) {
      $dat = date(time()) + 60 * 60 * 24 * $i;
      $str_dat = date('Y-m-d', $dat);
      if (!in_array($str_dat, $datums_besteld)) {
        $geldige_keuzes[] = $str_dat;
      }
    }

    return $geldige_keuzes;
  }

  public function voegOrderLijnenToe($order_id, $order_details) {
    $orderDAO = new OrderDAO();    
    $lijn_nr = 1;
    foreach ($order_details as $product_id => $aantal) {
      $orderDAO->voegOrderLijnToe($order_id, $lijn_nr, $product_id, $aantal);
      $lijn_nr++;
    }
    
  }

  public function voegOrderToe($datum_besteld, $datum_ophalen, $klant, $order_details) {
    $orderDAO = new OrderDAO();
    $orderDAO->voegOrderToe($datum_besteld, $datum_ophalen, $klant->getId());
    $order = $orderDAO->geefOrderVan($klant->getId(), $datum_ophalen);
    $this->voegOrderLijnenToe($order->getId(), $order_details);
  }
  
  public function geefGemaakteBestellingen($klant_id) {
    $orderDAO = new OrderDAO();
    return $orderDAO->geefAlleBestellingen($klant_id);
  }
  
  public function annuleerBestelling($order_id) {
    $orderDAO = new OrderDAO();
    $orderDAO->deleteOrder($order_id);
  }

}
