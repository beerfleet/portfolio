<?php

namespace JVB\Bakkerij\Business;

use JVB\Bakkerij\Lib\BCrypt;
use JVB\Bakkerij\Entities\Paswoord;
use JVB\Bakkerij\Entities\Klant;
use JVB\Bakkerij\Data\KlantDAO;
use JVB\Bakkerij\Data\PostcodeDAO;
use JVB\Bakkerij\Exceptions\EmailadresException;


class RegistratieService {
  
  public function geefAllePostcodes() {
    $postcodeDAO = new PostcodeDAO();
    return $postcodeDAO->haalPostcodesOp();
  }
  
  public function voegKlantToe(Klant $klant) {
    $klantDAO = new KlantDAO();
    $klantDAO->insertKlant($klant);
  }
  
  public function updateKlant($klant, $wijzig_paswoord = null, $paswoord = null) {
    $klantDAO = new KlantDAO();
    
    if (isset($wijzig_paswoord) && $wijzig_paswoord) {
      $crypto = new BCrypt();
      $hash = $crypto->password_hash($paswoord, PASSWORD_DEFAULT);
      $klant->setPaswoord($hash);
    }
    
    $klantDAO->updateKlant($klant);
  }
  
  public function verzendMail($email, $vnaam, $paswoord) {
    $to = $email;
    $subject = "Registratie nieuwe klant";
    $message = "Beste $vnaam, " . "\r\n" . "\r\n"
            . "Uw login is $email" . "\r\n"
            . "Uw gegenereerd paswoord bevindt zich tussen de '*' " . "\r\n"
            . "(6 tekens: hoofd- en kleine letters, cijfers en alle leestekens, " . "\r\n" . "\r\n"
            . "Om verwarring te vermijden, zal uw wachtwoord geen '*' bevatten. " . "\r\n"
            . "************" . "\r\n"
            . "***$paswoord***" . "\r\n"
            . "************";
    $headers = "From: noreply@VDAB.be" . "\r\n" .
            "X-Mailer: PHP/" . phpversion();
    mail($to, $subject, $message, $headers);
  }
  
  public function registreer(Klant $klant) {
    $paswoord = Paswoord::maak();
    $crypto = new BCrypt();
    $hash = $crypto->password_hash($paswoord, PASSWORD_DEFAULT);   
    $klant->setPaswoord($hash);
    $this->voegKlantToe($klant);      
    $this->verzendMail($klant->getEmail(), $klant->getVoornaam(), $paswoord);
  }    
  
  public function zoekKlant($email) {
    $klantDAO = new KlantDAO();
    return $klantDAO->zoekKlantOpEmail($email);    
  }
  
  public function geefKlantEnPostcodes($email) {
    $gegevens['klant'] = $this->zoekKlant($email);
    $gegevens['postcodes'] = $this->geefAllePostcodes();
    return $gegevens;
  }
  
  public function verifieerKlant($email, $paswoord) {
    $klant = $this->zoekKlant($email);    
    $crypto = new BCrypt();
    return $crypto->password_verify($paswoord, $klant->getPaswoord()) ? $klant : null;
  }
  
  public function resetPaswoord($email) {
    $klantDAO = new KlantDAO();
    $klant = $klantDAO->zoekKlantOpEmail($email);
    if ($klant->getId() == null)
      throw new EmailAdresException("Onbestaand emailadres opgegeven");
    $paswoord = Paswoord::maak();
    $crypto = new BCrypt();
    $hash = $crypto->password_hash($paswoord, PASSWORD_DEFAULT);
    $klantDAO->updatePaswoord($email, $hash);
    $this->verzendMail($email, $klant->getVoornaam(), $paswoord);
  }
  


}
