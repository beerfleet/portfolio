<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace JVB\Bakkerij\Business;

use JVB\Bakkerij\Lib\BCrypt;
use JVB\Bakkerij\Data\AdminDAO;
use JVB\Bakkerij\Data\KlantDAO;
use JVB\Bakkerij\Entities\Paswoord;

class AdminService {

    /* admin */  
  public function verifieerAdmin($email, $paswoord) {
    $admin = $this->zoekAdmin($email);
    $crypto = new BCrypt();
    return $crypto->password_verify($paswoord, $admin->getPaswoord()) ? $admin : null;
  }
  
  public function voegAdminToe($anaam, $vnaam, $email, $paswoord) {
    $adminDAO = new AdminDAO();
    $adminDAO->insertAdmin($anaam, $vnaam, $email, $paswoord);
  }
  
  public function registreerAdmin($vnaam, $anaam, $email, $paswoord) {    
    $crypto = new BCrypt();
    $hash = $crypto->password_hash($paswoord, PASSWORD_DEFAULT);    
    $this->voegAdminToe($anaam, $vnaam, $email, $hash);    
  }

  public function zoekAdmin($email) {
    $adminDAO = new AdminDAO();
    return $adminDAO->geefAdmin($email);
  }
  
  public function geefAlleKlanten() {
    $klantDAO = new KlantDAO();
    return $klantDAO->geeefAllekKlanten();
  }
  
  public function blokkeerKlant($klant_id) {
    $klantDAO = new KlantDAO();
    $klantDAO->blokkeerKlant($klant_id);
  }
  
  public function deblokkeerKlant($klant_id) {
    $klantDAO = new KlantDAO();
    $klantDAO->deblokkeerKlant($klant_id);
  }
  
  

}
