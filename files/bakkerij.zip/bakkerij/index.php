<?php

use Doctrine\Common\ClassLoader;
use JVB\Bakkerij\Entities\Output;

require_once './Doctrine/Common/ClassLoader.php';

$classloader = new ClassLoader("JVB", "src");
$classloader->register();

$output = new Output();
$vars = array();

try {
  if (isset($_SESSION['aangemeld'])) {
    $klant = unserialize($_SESSION['aangemeld']);
    $output->render('home.html.twig', array('klant' => $klant));
  } else if (isset($_SESSION["msg"])) {
    $msg = $_SESSION["msg"];
    switch ($msg) {
      case 'geregistreerd':
        $vars['msg'] = 'U bent geregistreerd. U ontvangt dadelijk een mailtje met uw gegevens.';
        break;
      case 'loginfout':
        $vars["msg"] = 'Aanmelden mislukt.';
        break;
    }
    unset($_SESSION["msg"]);
    
    // email
    if (isset($_COOKIE['login']))
      $vars['login'] = $_COOKIE['login'];
    
    $output->render('loginscherm.html.twig', $vars);
  } else {
    if (isset($_COOKIE['login'])) {
      $vars['login'] = $_COOKIE['login'];
    }
    $output->render('loginscherm.html.twig', $vars);
  }
} catch (Exception $ex) {
  $output->render('probleem.html.twig', array('probleem' => $ex->getMessage()));
}
