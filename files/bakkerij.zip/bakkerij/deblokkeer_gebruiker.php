<?php

use Doctrine\Common\ClassLoader;
use JVB\Bakkerij\Entities\Output;
use JVB\Bakkerij\Business\AdminService;

require_once './Doctrine/Common/ClassLoader.php';

$classloader = new ClassLoader("JVB", "src");
$classloader->register();

$output = new Output();

try {
  
  if (!isset($_SESSION['admin'])) {
    header('Location: admin.php');
    exit(0);
  }
  
  if (isset($_GET['id'])) {
    $klant_id = $_GET['id'];
    $adminSrvc = new AdminService();
    $adminSrvc->deblokkeerKlant($klant_id);
  }
  
  header('Location: admin.php');
  exit(0);
  
} catch (Exception $e) {
  $output->render('probleem.html.twig', array('probleem' => $e->getMessage()));
}