<?php

use Doctrine\Common\ClassLoader;
use JVB\Bakkerij\Entities\Output;
use JVB\Bakkerij\Business\AdminService;

require_once './Doctrine/Common/ClassLoader.php';

$classloader = new ClassLoader("JVB", "src");
$classloader->register();

$output = new Output();

try {
  $vars = array();
  if (!isset($_SESSION['admin'])) {
    if (isset($_SESSION['msg'])) {
      $vars['msg'] = $_SESSION['msg'];
    }
    if (isset($_COOKIE['login_admin'])) {
      $vars['login_admin'] = $_COOKIE['login_admin'];
    }
    $output->render('admin_logon.html.twig', $vars);
  } else {
    
    $vars['admin'] = $_SESSION['admin'];    
    $adminSrvc = new AdminService();
    
    $klanten = $adminSrvc->geefAlleKlanten();
    $vars['klanten'] = $klanten;
    $output->render('admin.html.twig', $vars);
    
    echo '<pre>';
    print_r($klanten);
    echo '</pre>';
  }
} catch (Exception $e) {
  $output->render('probleem.html.twig', array('probleem' => $e->getMessage()));
}