<?php

use Doctrine\Common\ClassLoader;
use JVB\Bakkerij\Entities\Output;
use JVB\Bakkerij\Business\RegistratieService;
use JVB\Bakkerij\Exceptions\EmailadresException;

require_once './Doctrine/Common/ClassLoader.php';

$classloader = new ClassLoader("JVB", "src");
$classloader->register();

$output = new Output();

try {
  if (isset($_SESSION["registratie"])) {
    $klant = unserialize($_SESSION["registratie"]);
    $registratieSrv = new RegistratieService();
    $registratieSrv->registreer($klant);
    unset($_SESSION["registratie"]);
    $_SESSION["msg"] = 'geregistreerd';
    header("Location: index.php");
  } else {    
    header('Location: registratieformulier.php');
    exit(0);
  }
} catch (EmailadresException $e) {
  $_SESSION['emailbestaaterr'] = $e->getMessage();
  header('Location: registratieformulier.php');
  exit(0);
} catch (Exception $e) {
  $output->render('probleem.html.twig', array('probleem' => $e->getMessage()));
}
