<?php

use Doctrine\Common\ClassLoader;
use JVB\Bakkerij\Entities\Output;
use JVB\Bakkerij\Business\BestelService;

require_once './Doctrine/Common/ClassLoader.php';

$classloader = new ClassLoader("JVB", "src");
$classloader->register();

$output = new Output();

try {

  if (!isset($_SESSION["aangemeld"])) {
    header('Location: index.php');
    exit(0);
  }
  
  if (isset($_GET['id'])) {
    $order_id = $_GET['id'];
  }    
  
  $bestelSrvc = new BestelService();
  $bestelSrvc->annuleerBestelling($order_id);
  
  header('Location: toon_alle_bestellingen.php');
  
} catch (Exception $e) {
  $output->render('probleem.html.twig', array('probleem' => $e->getMessage()));
}