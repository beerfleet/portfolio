<?php

use Doctrine\Common\ClassLoader;
use JVB\Bakkerij\Entities\Output;
use JVB\Bakkerij\Business\BestelService;

require_once './Doctrine/Common/ClassLoader.php';

$classloader = new ClassLoader("JVB", "src");
$classloader->register();

$output = new Output();

try {
  $vars = array();

  if (!isset($_SESSION['aangemeld'])) {
    header('Location: index.php');
    exit(0);
  }

  $vars['klant'] = unserialize($_SESSION['aangemeld']);
  
  if (isset($_SESSION['boodschap'])) {
    $vars['boodschap'] = $_SESSION['boodschap'];
    unset($_SESSION['boodschap']);
  }
  
  $bestelSrvc = new BestelService();
  $klant = unserialize($_SESSION['aangemeld']);
  $bestellingen = $bestelSrvc->geefGemaakteBestellingen($klant->getId());
  if (count($bestellingen) == 0) {
    $vars['boodschap'] = 'Er staan momenteel geen bestellingen op uw naam.';
  }
  $vars['bestellingen'] = $bestellingen;
  
  $output->render('alle_bestellingen.html.twig', $vars);

  /*echo '<pre>';
  print_r($bestellingen);
  echo '</pre>';
   * 
   */
 

} catch (Exception $e) {
  $output->render('probleem.html.twig', array('probleem' => $e->getMessage()));
}