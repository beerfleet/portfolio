<?php

use Doctrine\Common\ClassLoader;
use JVB\Bakkerij\Entities\Output;

require_once './Doctrine/Common/ClassLoader.php';

$classloader = new ClassLoader("JVB", "src");
$classloader->register();

$output = new Output();

try {
  if (!isset($_SESSION["aangemeld"])) {
    header('Location: index.php');
    exit(0);
  }
  if (isset($_SESSION['winkelmand'])) {
    $id = $_GET["id"];
    if (isset($_SESSION['winkelmand'][$id])) {
      $_SESSION['winkelmand'][$id] ++;
    } else {
      $_SESSION['winkelmand'][$id] = 1;
    }
  }
  header('Location: maak_bestelling.php');
  exit(0);
} catch (Exception $e) {
  $output->render('probleem.html.twig', array('probleem' => $e->getMessage()));
}
