<?php

use Doctrine\Common\ClassLoader;
use JVB\Bakkerij\Entities\Output;

require_once './Doctrine/Common/ClassLoader.php';

$classloader = new ClassLoader("JVB", "src");
$classloader->register();

$output = new Output();
$rij = array(1, 3, 4, 5);
$vars = array('vars' => $rij);
$output->render("test.html.twig", array('vars' => array("1", "2", "3", "4", "5")));
