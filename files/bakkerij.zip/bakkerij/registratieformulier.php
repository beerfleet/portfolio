<?php

use Doctrine\Common\ClassLoader;
use JVB\Bakkerij\Entities\Output;
use JVB\Bakkerij\Business\RegistratieService;
use JVB\Bakkerij\Entities\Klant;

require_once './Doctrine/Common/ClassLoader.php';

$classloader = new ClassLoader("JVB", "src");
$classloader->register();

$output = new Output();


try {
  $registratieSrvc = new RegistratieService();
  $postcodes = $registratieSrvc->geefAllePostcodes();
  $vars = array('postcodes' => $postcodes);

  // redirect komt van post submit
  if (isset($_POST["registreer"])) {
    $err = false;
    $voornaam = filter_input(INPUT_POST, 'voornaam');
    $achternaam = filter_input(INPUT_POST, 'achternaam');
    $straat = filter_input(INPUT_POST, 'straat');
    $huisnummer = filter_input(INPUT_POST, 'huisnummer');
    $postcode_id = filter_input(INPUT_POST, 'postcode');
    $email = filter_input(INPUT_POST, 'email', FILTER_VALIDATE_EMAIL);

    $trim_voornaam = trim($voornaam);
    if (empty($trim_voornaam)) {
      $err = true;
      $vNaamErr = true;
      $voornaam = '';
      $vars['vnaamerr'] = $vNaamErr;
    }
    $trim_achternaam = trim($achternaam);
    if (empty($trim_achternaam)) {
      $err = true;
      $aNaamErr = true;
      $achternaam = '';
      $vars['anaamerr'] = $aNaamErr;
    }
    $trim_straat = trim($straat);
    if (empty($trim_straat)) {
      $err = true;
      $straatErr = true;
      $straat = '';
      $vars['straaterr'] = $straatErr;
    }
    $trim_huisnummer = trim($huisnummer);
    if (empty($trim_huisnummer)) {
      $err = true;
      $huisnrErr = true;
      $huisnummer = '';
      $vars['huisnrerr'] = $huisnrErr;
    }
    if (!$email) {
      $err = true;
      $emailErr = true;
      $email = '';
      $vars['emailerr'] = $emailErr;
    }

    // auto vul in form na post        
    $vars['voornaam'] = $voornaam;
    $vars['achternaam'] = $achternaam;
    $vars['straat'] = $straat;
    $vars['huisnummer'] = $huisnummer;
    $vars['postcode_id'] = $postcode_id;
    $vars['email'] = $email;

    if ($err) {
      $output->render('registreer.html.twig', $vars);
    } else {
      // REGISTREER            
      $postcode = $postcodes[$postcode_id];
      $klant = new Klant(null, $voornaam, $achternaam, $straat, $huisnummer, $postcode, $email, null);
      $_SESSION["registratie"] = serialize($klant);
      header("Location: registreer.php");   
      exit(0);
    }
  } else {
    // ga naar registratieform
    if (isset($_SESSION['emailbestaaterr']))
      $vars['emailbestaaterr'] = $_SESSION['emailbestaaterr'];
    if (isset($_SESSION['registratie'])) {
      $klant = unserialize($_SESSION['registratie']);
      $vars['voornaam'] = $klant->getVoornaam();
      $vars['achternaam'] = $klant->getAchternaam();
      $vars['straat'] = $klant->getStraat();
      $vars['huisnummer'] = $klant->getHuisnummer();
      $vars['postcode_id'] = $klant->getPostcode()->getId();
      $vars['email'] = '';
      unset($_SESSION['registratie']);
    }
    
    //email
    if (isset($_COOKIE['login'])) 
      $vars['login'] = $_COOKIE['login'];
    
    $output->render('registreer.html.twig', $vars);
  }
} catch (Exception $e) {
  $output->render('probleem.html.twig', array('probleem' => $e->getMessage()));
}
