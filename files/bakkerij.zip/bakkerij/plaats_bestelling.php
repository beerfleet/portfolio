<?php

use Doctrine\Common\ClassLoader;
use JVB\Bakkerij\Entities\Output;
use JVB\Bakkerij\Business\BestelService;

require_once './Doctrine/Common/ClassLoader.php';

$classloader = new ClassLoader("JVB", "src");
$classloader->register();

$output = new Output();

try {
  $vars = array();
  if (!isset($_SESSION["aangemeld"])) {
    header('Location: index.php');
    exit(0);
  }  

  if (isset($_POST['datum']) && !is_null($_POST['datum'])) {
    $datum_ophalen = $_POST["datum"];
    $order = $_SESSION['winkelmand'];
    $klant = unserialize($_SESSION['aangemeld']);
    $bestelSrvc = new BestelService();
    $bestelSrvc->voegOrderToe(date('Y-m-d', time()), $datum_ophalen, $klant, $order);
    unset($_SESSION['winkelmand']);
  } else {
    $msg = "Gelieve een datum te kiezen waarop u de bestelling zal komen halen.";
    $_SESSION['boodschap'] = $msg;
    header('Location: overzicht_bestelling.php');
    exit(0);
  }
  
  header('Location: toon_alle_bestellingen.php');
  exit(0);
  
  echo '<pre>';
  print_r($vars);
  echo '</pre>';
  
} catch (Exception $e) {
  $output->render('probleem.html.twig', array('probleem' => $e->getMessage()));
}