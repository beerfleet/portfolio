<?php

use Doctrine\Common\ClassLoader;
use JVB\Bakkerij\Entities\Output;
use JVB\Bakkerij\Business\BestelService;

require_once './Doctrine/Common/ClassLoader.php';

$classloader = new ClassLoader("JVB", "src");
$classloader->register();

$output = new Output();

try {
  $bestelSrvc = new BestelService();
  $selectie = $_SESSION['winkelmand'];
  $bestelling = $bestelSrvc->geefBestelOverzicht($selectie);
  
  $vars = array('bestelling' => $bestelling);
  $output->render('overzicht_bestelling.html.twig', $vars);
  
  echo '<pre>';
  print_r($bestelling);
  echo '</pre>';
  
} catch (Exception $e) {
  $output->render('probleem.html.twig', array('probleem' => $e->getMessage()));
}
