<?php

use Doctrine\Common\ClassLoader;
use JVB\Bakkerij\Entities\Output;
use JVB\Bakkerij\Business\BestelService;
use JVB\Bakkerij\Exceptions\BestellingException;

require_once './Doctrine/Common/ClassLoader.php';

$classloader = new ClassLoader("JVB", "src");
$classloader->register();

$output = new Output();

try {
  if (!isset($_SESSION["aangemeld"])) {
    header('Location: index.php');
    exit(0);
  }
  
  if (isset($_SESSION['boodschap'])) {
    $vars['boodschap'] = $_SESSION['boodschap'];
    unset($_SESSION['boodschap']);    
  }
  
  if (!isset($_SESSION['winkelmand']) || count($_SESSION['winkelmand']) == 0) {
    header('Location: maak_bestelling.php');
    exit(0);
  }
  
  $bestelSrvc = new BestelService();
  $selectie = $_SESSION['winkelmand'];
  $klant = unserialize($_SESSION["aangemeld"]);
  $klant_id = $klant->getId();
  $bestelling = $bestelSrvc->geefBestelOverzicht($selectie, $klant_id);

  $vars['klant'] = $klant;
  $vars['bestelling'] = $bestelling['producten'];
  $vars['datums'] = $bestelling['datums'];
  $output->render('overzicht_bestelling.html.twig', $vars);

  /*
  echo '<pre>';
  print_r($vars);
  echo '</pre>';  
   * 
   */
  
} catch (BestellingException $e) {
  header('Location: toon_alle_bestellingen.php');
  exit(0);
} catch (Exception $e) {
  $output->render('probleem.html.twig', array('probleem' => $e->getMessage()));
}
