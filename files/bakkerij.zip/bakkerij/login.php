<?php

use Doctrine\Common\ClassLoader;
use JVB\Bakkerij\Entities\Output;
use JVB\Bakkerij\Business\RegistratieService;

require_once './Doctrine/Common/ClassLoader.php';

$classloader = new ClassLoader("JVB", "src");
$classloader->register();

$output = new Output();


try {
  
  // verwerk enkel na POST operatie
  if (isset($_POST["login"])) {
    $loginSrvc = new RegistratieService();
    $email = filter_input(INPUT_POST, 'login', FILTER_VALIDATE_EMAIL);
    $paswoord = $_POST["paswoord"];
    $klant = $loginSrvc->verifieerKlant($email, $paswoord);
    
    // aanmelden
    if ($klant) {
      $_SESSION["aangemeld"] = serialize($klant);      
      setcookie('login', $klant->getEmail(), time() + 60 * 60 * 24 * 30 * 12);
      header('Location: index.php');
      exit(0);
    } else {
      $_SESSION["msg"] = 'loginfout';
      header('Location: index.php');
      exit(0);
    }
  
  } else {
    // bij rechstreekse access => redirect naar index  
    header('Location: index.php');
    exit(0);
  }
  
} catch (Exception $e) {
  $output->render('probleem.html.twig', array('probleem' => $e->getMessage()));
}
